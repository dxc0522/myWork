const
  // 格式化时间
  formatTime = (res, num) => {
    let date = new Date(res);
    if (num) {
      date = new Date(date.getTime() + num);
    }
    const year = date.getFullYear(),
      month = date.getMonth() + 1,
      day = date.getDate(),
      hour = date.getHours(),
      minute = date.getMinutes(),
      second = date.getSeconds();
    return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
  },
  formatNumber = n => {
    n = n.toString()
    return n[1] ? n : '0' + n
  },
  // 比较版本号
  version = (a, b) => {
    const toNum = a => {
      var a = a.toString();
      //也可以这样写 var c=a.split(/\./);
      var c = a.split('.');
      var num_place = ["", "0", "00", "000", "0000"], r = num_place.reverse();
      for (var i = 0; i < c.length; i++) {
        var len = c[i].length;
        c[i] = r[len] + c[i];
      }
      var res = c.join('');
      return res;
    };
    return toNum(a) < toNum(b)
    // 返回的是前面的版本号是否大于等于后边的
  },
  // 请求网络
  // request = (url, mapdata, page, success, fail) => {
  //   if (typeof success != 'function' || typeof fail != 'function') {
  //     return
  //   }
  //   var app = getApp()
  //   wx.request({
  //     url: url,
  //     data: {
  //       key: app.globalData.appkey,
  //       page: page,
  //       pagesize: app.globalData.pagesize
  //     },
  //     success: function (res) {
  //       if (res.data.error_code == 0) {
  //         success(res.data)
  //       } else {
  //         fail(res.data.reason)
  //       }
  //     },
  //     fail: function () {
  //       fail('网络错误')
  //     }

  //   })
  // },
  // 遍历权限查询
  eachControl = (dataList, need) => {
    for (var i in dataList) {
      if (dataList[i] == need) {
        return true
      }
    }
    return false
  },
  // 请求网络
  requestData = (url, mapData, success, fail) => {
    var app = getApp()
    wx.request({
      url: url,
      data: mapData,
      success: function (res) {
        if (res.data.statusCode == 200 && res.data.status == "success") {
          success(res.data)
        } else {
          fail(res.data.message)
        }
      },
      fail: function () {
        fail('网络错误请联系客服')
      }

    })
  },
  // 验证姓名
  checkName = data => {
    var checkFn = /[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi;
    return checkFn.test(data) && data.length <= 4
  },
  // 验证手机号
  checkPhone = data => {
    var mobile = /^[1][3,4,5,7,8][0-9]{9}$/;
    return mobile.test(data);
  },
  // 格式化时间 Y-M-D
  readyTime = date => {
    var n = date;
    var date = new Date(n);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    return (Y + M + D)
  },
  // 获取用户地址
  getUserAds = (backFn, fillFn) => {
    const that = this;
    wx.showLoading({ mask: true, title: "疯狂加载中" })
    getControl()
    // 直接获取权限
    function getControl() {
      wx.chooseAddress({
        success: function (res) {
          // 有权限直接获取
          if (backFn != undefined) {
            backFn(res)
          }
          wx.hideLoading()
        }, fail(err) {
          setControl()
        }
      })
    }
    // 通过设置获取权限
    function setControl() {
      wx.getSetting({
        success(res) {
          // 判断权限
          if (!res.authSetting['scope.address']) {
            // 没有权限
            wx.showModal({
              title: '尚未获取权限',
              confirmText: '去授权',
              confirmColor: "#e74b42",
              cancelText: "放弃授权",
              cancelColor: "#ddd",
              success: function (res) {
                // 同意授权
                if (res.confirm) {
                  wx.openSetting({
                    success: function (res) {
                      wx.authorize({
                        scope: 'scope.address',
                        success(res) {
                          getControl()
                        }, fail(res) {
                          console.log("未同意授权")
                          if (fillFn != undefined) {
                            fillFn()
                          }
                        }
                      })
                    }
                  })
                } else if (res.cancel) {
                  // 拒绝授权
                  if (fillFn != undefined) {
                    fillFn()
                  }
                }
              }
            })
            // 隐藏加载框
            wx.hideLoading()
          } else {
            // 有权限
            getControl()
          }
        }
      })
    }
  },
  // 分享路径
  sharePage = () => {
    let pushData = { url: "" };
    const pages = getCurrentPages(),
      nowPage = pages[pages.length - 1];
    pushData.url = nowPage.route + "?";
    for (var i in nowPage.options) {
      pushData.url += (i + "=" + nowPage.options[i] + "&")
    }
    return {
      path: pushData.url,
      success: function (res) {
        console.log(res)
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  // 正确弹窗
  oks = data => {
    wx.showToast({
      title: data.msg,
      icon: 'success',
      duration: data.time ? data.time : 2000,
      mask: true
    })
  },
  // 错误弹窗
  err = data => {
    wx.showToast({
      title: data.msg,
      image: '/img/error.png',
      duration: data.time ? data.time : 2000,
      mask: true
    })
  };
module.exports = {
  formatTime,//格式化时间
  requestData,//获取数据
  checkName,//校验名字
  checkPhone,//校验手机号
  eachControl,//查权限
  version,//比较版本号
  getUserAds,//获取用户位置
  sharePage,//分享页面
}


