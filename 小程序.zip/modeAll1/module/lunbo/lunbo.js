// module/lunbo/lunbo.js
const srcs = ["", "/pages/index/view/newMsg/newMsg?id=", "/pages/index/view/caseMsg/caseMsg?id=", "/pages/shoping/goodsMsg/goodsMsg?id="]
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    getData: {
      type: null,
      observer: function (newVal, oldVal) {
        // console.log(newVal)
        // newVal.forEach((item, num) => {
        //   newVal[num].src = srcs[item.menuId] + item.itemId
        // })
        // this.setData({
        //   getData: newVal
        // })
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
  },
  attached() {
    this.setData({
      allColor: app.globalData.color
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    openPage(e) {
      const types = e.currentTarget.dataset.type,
        num = e.currentTarget.dataset.num;
      if (types != 0 && num) {
        wx.navigateTo({
          url: srcs[types] + num,
        })
      }
    }
  }
})
