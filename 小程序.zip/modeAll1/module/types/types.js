// module/types/types.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    typeList: {
      type: null,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    _backPage(e) {
      const pages = getCurrentPages();
      const prePage = pages[pages.length - 2];
      prePage.setData({
        taps: e.target.id
      })
      wx.navigateBack({
        delta: 1
      })
    }
  }
})
