// module/_payType/payType.js
const app = getApp();
const https = require('../../utils/util.js');
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    showType: {
      type: null,
      observer(newVal, oldVal) {
        const that = this;
        if (newVal) {
          if (app.globalData.userInfo == null) {
            app.getUserMsg(function () {
              that.setData({
                myMoney: app.globalData.userInfo.balance
              }, function () {
                that._show()
              })
            })
          } else {
            that.setData({
              myMoney: app.globalData.userInfo.balance
            }, function () {
              that._show()
            })
          }
        }
      }
    },
    orderId: {
      type: null,
      observer(newVal, oldVal) {
      }

    }
  },
  attached() {
    this.setData({
      allColor: app.globalData.color
    })
  },
  /**
   * 组件的初始数据
   */
  data: {
    payType: null,
    showAlert: false,
  },
  /**
   * 组件的方法列表
   */
  methods: {
    _show() {
      this.setData({
        showAlert: true
      })
    },
    _close() {
      this.setData({
        showAlert: false
      })
      this._updata()
    },
    _updata() {
      // 传递到外部
      var myEventDetail = {} // detail对象，提供给事件监听函数
      var myEventOption = {} // 触发事件的选项
      this.triggerEvent('tellMe', myEventDetail, myEventOption)
    },
    // 付款方式
    _buyType(event) {
      this.data.payType = event.detail.value;
    },
    // 去付款
    _buy() {
      const that = this;
      const payType = that.data.payType;
      console.log(that.data.orderId)
      // 判断支付方式
      if (payType == "yuE") {
        this._close();
        // 判断是否绑定手机号
        if (app.globalData.userInfo.phone != undefined) {
          let urls = '/pages/pay/index/index?order=' + that.data.orderId.id + "&type=" + that.data.orderId.type;
          if (that.data.orderId.money != undefined) {
            urls += "&money=" + that.data.orderId.money
          }
          wx.navigateTo({
            url: urls
          })
        } else {
          wx.navigateTo({
            url: '/pages/pay/bindPhone/bindPhone'
          })
        }
      } else if (payType == "wx") {
        this._close()
        console.log(that.data.orderId.id, app.globalData.extAppid)
        // 发送微信支付请求
        https.requestData(app.globalData.domain + app.urls.wxPay, {
          id: that.data.orderId.id,
        }, back => {
          console.log(back)
          const data = back.data;
          wx.requestPayment({
            'timeStamp': data.timeStamp,
            'nonceStr': data.nonceStr,
            'package': data.package,
            'signType': data.signType,
            'paySign': data.paySign,
            'success': function (res) {
              console.log(res)
              setTimeout(function () {
                app.getUserMsg(function () {
                  wx.navigateBack({
                    delta: 1,
                  })
                })
              }, 1000)
            },
            'fail': function (res) {
              https.err({msg:"支付不可用"})
            }
          })
        }, err => {
          console.log(err)
        })
      }
    },
    _myMOney() {
      this.setData({
        myMoney: app.globalData.userInfo.balance
      })
    }
  }
})
