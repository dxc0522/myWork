//app.js
const https = require('utils/util.js');
var loginStatus = true;
App({
  globalData: {
    userInfo: null,
    miniBinId: "",//绑定id，企业id
    tempVersion: "",//版本号
    color: "",//主题色
    domain: "",// http://WWW.xxxx.com
    companyInfo: "", //公司信息
    control: null,//权限
  },
  urls: {
    loginId: "/chuizi_wchat/system/wx/wxUserLogin/json",//获取code信息
    updataUser: "/chuizi_wchat/system/qwxuser/look/json",//刷新用户信息
    menus: "/chuizi_wchat/system/qtmplrole/lookrole/json",//菜单信息
    loginUser: "/chuizi_wchat/system/qwxuser/login/json",//登录用户
    companyInfo: "/chuizi_wchat/system/qminiappbinding/look/json",//获取公司信息
    shopMsg: "/chuizi_wchat/system/qmorecomplete/list/json",//店面信息    
    imgType: "/chuizi_wchat/system/qenvironmentcategory/list/json",// 环境相册分类
    imgList: "/chuizi_wchat/system/qenvironment/list/json",// 环境相册列表
    lunbo: "/chuizi_wchat/system/qtmpllunbo/list/json",//轮播
    news: "/chuizi_wchat/system/qtmplnews/list/json",//获取小程序新闻表列表
    newTypes: "/chuizi_wchat/system/qtmplnewscategory/list/json",//新闻分类列表
    newMsg: "/chuizi_wchat/system/qtmplnews/look/json",//新闻详情
    anliTypes: "/chuizi_wchat/system/qcasecategory/list/json",//案例分类
    anli: "/chuizi_wchat/system/qcase/list/json",//案例列表
    anliMsg: "/chuizi_wchat/system/qcase/look/json",//案例详情
    anliTalkList: "/chuizi_wchat/system/qcasecommend/list/json",//案例评价列表
    anliTalkSub: "/chuizi_wchat/system/qcasecommend/save/json",//评价案例
    shopingType: "/chuizi_wchat/system/qgoodcategory/list/json",//产品分类
    shopingList: "/chuizi_wchat/system/qgood/list/json",//产品列表
    goodsMsg: "/chuizi_wchat/system/qgood/look/json",//产品详情
    goodsTalk: "/chuizi_wchat/system/qgoodcommend/look/json",//产品评论详情
    goodsTalkList: "/chuizi_wchat/system/qgoodcommend/list/json",//产品评论列表
    addGoodsTalk: "/chuizi_wchat/system/qgoodcommend/save/json",//新增产品评论
    goodsTalkNum: "/chuizi_wchat/system/qgoodcommend/lookCount/json",//评论数量    
    myTalk: "/chuizi_wchat/system/qgoodcommend/mylist/json",//我的评论
    serviceList: "/chuizi_wchat/system/qonlineservice/list/json",//在线客服列表
    saveCollect: "/chuizi_wchat/system/qcollect/saveordelect/json",//收藏案例
    meCollect: "/chuizi_wchat/system/qcollect/list/json",//我的案例收藏列表
    meCard: "/chuizi_wchat/system/qusercard/list/json",//我的卡券
    seachCard: "/chuizi_wchat/system/qusercard/look/json",// 查询卡券
    buyCard: "/chuizi_wchat/system/qgoodcard/list/json",//购买卡券列表
    czList: "/chuizi_wchat/system/qrecharge/list/json",//去充值列表
    moneyChange: "/chuizi_wchat/system/qmoneydetail/list/json",//余额变动记录
    formList: "/chuizi_wchat/system/qorder/list/json",//全部订单
    formMsg: "/chuizi_wchat/system/qorder/look/json",//订单详情
    province: "/chuizi_wchat/system/province/list/json",//省
    city: "/chuizi_wchat/system/city/list/json",//市
    area: "/chuizi_wchat/system/area/list/json",//区
    bankList: "/chuizi_wchat/system/bank/list/json",//银行卡列表
    meBankList: "/chuizi_wchat/system/quserbank/list/json",//我的银行卡列表
    addBank: "/chuizi_wchat/system/quserbank/update/json",//新增银行卡
    delBank: "/chuizi_wchat/system/quserbank/delete/json",//删除银行卡
    isCollect: "/chuizi_wchat/system/qcollect/isQcollect/json",//是否收藏
    tixian: "/chuizi_wchat/system/qwithdraw/update/json",//提现
    tixianList: "/chuizi_wchat/system/qwithdraw/list/json",//提现列表
    adsList: "/chuizi_wchat/system/qaddress/list/json",//用户地址
    addAds: "/chuizi_wchat/system/qaddress/save/json",//新增收货地址
    remAds: "/chuizi_wchat/system/qaddress/delete/json",//删除收货地址
    defultAds: "/chuizi_wchat/system/qaddress/update/json",//编辑地址
    like: "/chuizi_wchat/system/qpraise/update/json",//点赞接口
    likeNum: "/chuizi_wchat/system/qpraise/list/json",//点赞数查询
    likeType: "/chuizi_wchat/system/qcasecommend/list/json",//点赞状态
    salesTeam: "/chuizi_wchat/system/qdistribution/list/json",//分销团队
    salesNum: "/chuizi_wchat/system/qdistribution/lookCount/json",//分销人数
    salesMoney: "/chuizi_wchat/system/qmoneydetail/mylist/json",//分销奖励
    help: "/chuizi_wchat/system/feedback/update/json",//帮助与反馈
    addForm: "/chuizi_wchat/system/qorder/submit/json",//提交订单
    affirm: "/chuizi_wchat/system/qorder/getSend/json",//确认收货
    systemNote: "/chuizi_wchat/system/qmessage/list/json",//系统消息
    yuEPay: "/chuizi_wchat/system/qwxuser/balancePay/json",//余额支付
    cardPay: "/chuizi_wchat/system/qwxuser/payCard/json",//卡卷支付
    shopPay: "/chuizi_wchat/system/qwxuser/shopPay/json",//到店付
    bindPhone: "/chuizi_wchat/system/qwxuser/addPhone/json",//绑定手机号
    edtPhone: "/chuizi_wchat/system/qwxuser/changePhone/json",//修改手机号
    setPwd: "/chuizi_wchat/system/qwxuser/addPassWord/json",//设置支付密码
    edtPwd: "/chuizi_wchat/system/qwxuser/updatePassWord/json",//修改手机密码
    sendCode: "/chuizi_wchat/system/qsmspush/send/json",//发送验证码
    control: "/chuizi_wchat//system/qtmplmenu/listMenu/json",//权限控制
    wxPay: "/chuizi_wchat/system/wxxcxpay/xcxpay/json",//微信支付
    imgUpload: "/chuizi_wchat/fileupload",//图片上传
    edtMe: "/chuizi_wchat/system/qwxuser/update/json",//个人信息修改
    noLook: "/chuizi_wchat/system/qwxuser/statics/json",//未读消息
  },
  // 获取用户信息权限
  getUserMsg(backFn, fillFn) {
    const that = this;
    wx.showLoading({ mask: true, title: "获取授权中" })
    // 登录
    wx.login({
      success: res => {
        console.log(res)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        https.requestData(that.globalData.domain + that.urls.loginId, {
          id: that.globalData.miniBinId,
          code: res.code
        }, data => {
          data.data = JSON.parse(data.data)
          console.log(data)
          // 获取用户信息
          wx.getUserInfo({
            withCredentials: true,
            lang: 'zh_CN',
            success: function (res) {
              // 获取用户个人信息              // 有权限直接获取
              https.requestData(that.globalData.domain + that.urls.loginUser, {
                miniBinId: that.globalData.miniBinId,
                version: that.globalData.tempVersion,
                wxOpenId: data.data.openid,
                nickName: res.userInfo.nickName,
                sex: res.userInfo.gender,
                header: res.userInfo.avatarUrl,
                provinceName: res.userInfo.province,
                cityName: res.userInfo.city
              }, data => {
                that.globalData.userInfo = data.data;
                if (backFn != undefined) {
                  backFn()
                }
                wx.hideLoading()
              }, err => {
                console.log(err)
              })
            }, fail() {
              // 无权限再次调取
              wx.getSetting({
                success(res) {
                  console.log("获取权限后")
                  // 判断权限
                  if (!res.authSetting['scope.userInfo']) {
                    // 没有权限
                    wx.showModal({
                      title: '尚未获取权限',
                      confirmText: '去授权',
                      confirmColor: "#e74b42",
                      cancelText: "放弃授权",
                      cancelColor: "#ddd",
                      success: function (res) {
                        if (res.confirm) {
                          wx.openSetting({
                            success: function (res) {
                              wx.authorize({
                                scope: 'scope.userInfo',
                                success(res) {
                                  console.log(res)
                                  that.getUserMsg()
                                  // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
                                }, fail(res) {
                                  console.log("授权失败")
                                  if (fillFn != undefined) {
                                    fillFn()
                                  }
                                }
                              })
                            }
                          })
                        } else if (res.cancel) {
                          console.log("拒绝授权")
                          if (fillFn != undefined) {
                            fillFn()
                          }
                        }
                      }
                    })
                    // 隐藏加载框
                    wx.hideLoading()
                  } else {
                    // 有权限
                    that.getUserMsg()
                  }
                }
              })
              // 出现选项框直接关闭加载
            }
          })
        }, err => {
          console.log(err)
        })
      }
    })
  },
  // 刷新用户信息
  updataUser(backFn) {
    const that = this;
    wx.showLoading()
    // 获取用户个人信息
    https.requestData(that.globalData.domain + that.urls.updataUser, {
      miniBinId: that.globalData.miniBinId,
      id: that.globalData.userInfo.id
    }, data => {
      that.globalData.userInfo = data.data;
      if (backFn != undefined) {
        backFn()
      }
      wx.hideLoading()
    }, err => {
      console.log(err)
    })
  },
  // 获取用户权限控制
  userControl(back) {
    const that = this;
    // 判断本地有无权限
    // wx.getStorage({
    //   key: 'controls',
    //   success: function (res) {
    //     console.log(res.data)
    //     that.globalData.controls = JSON.parse(res.data);
    //     back(res.data)
    //     updataControl()
    //   }, fail(err) {
    //     // 没有权限存储
    //     updataControl(function (data) {
    //       back(data)
    //     })
    //   }
    // })
    // // 刷新控制权限
    // function updataControl(callback) {
    //   var t = setInterval(function () {
    //     if (that.globalData.domain != "") {
    //       // 清除定时器
    //       clearInterval(t);
    //       https.requestData(that.globalData.domain + that.urls.control, {
    //         miniBindId: that.globalData.miniBinId,
    //       }, data => {
    //         let controls = [];
    //         for (var i in data.data) {
    //           if (data.data[i].dburl != undefined) {
    //             controls.push(data.data[i].dburl)
    //           }
    //         }
    //         that.globalData.controls = controls;
    //         if (callback != undefined) {
    //           callback(controls)
    //         }
    //         // 存储在本地
    //         wx.setStorage({
    //           key: "control",
    //           data: JSON.stringify(controls),
    //         })
    //       }, err => {
    //         console.log(err)
    //       })
    //     }
    //   }, 100)
    // }
    wx.getSystemInfo({
      success: function (res) {
        if (https.version(res.SDKVersion, "1.9.0")) {
          wx.showLoading({
            title: "微信版本太低",
            mask: true
          })
        } else {
          function updataControl() {
            https.requestData(that.globalData.domain + that.urls.control, {
              miniBindId: that.globalData.miniBinId,
            }, data => {
              let controls = [];
              for (var i in data.data) {
                if (data.data[i].dburl != undefined) {
                  controls.push(data.data[i].dburl)
                }
              }
              that.globalData.controls = controls;
              // 获取权限后回调
              back(controls)
            }, err => {
              console.log(err)
            })
          }
          // 获取extJson信息 暂时屏蔽
          // let extConfig = wx.getExtConfigSync ? wx.getExtConfigSync() : {}
          // console.log(extConfig)
          // wx.getExtConfig({
          //   success: function (res) {
          //     that.globalData.miniBinId = res.extConfig.miniBinId;
          //     that.globalData.tempVersion = res.extConfig.tempVersion;
          //     that.globalData.domain = res.extConfig.domain;
          //     that.globalData.color = res.extConfig.color.slice(1);
          //     that.globalData.extAppid = res.extConfig.extAppid;
          // updataControl()
          //   }
          // })
          that.globalData.miniBinId = "179";
          that.globalData.tempVersion = "1";
          that.globalData.domain = "https://api.yunqihui.net";
          that.globalData.color = "13a928";
          that.globalData.extAppid = "wx89579dee9b66d500";
          updataControl()
          // 付费miniBinId：179
          // 免费miniBinId：173
        }
      }
    })
  },
  getMenus(num, back) {
    const that = this;
    // 获取菜单
    https.requestData(that.globalData.domain + that.urls.menus, {
      miniBinId: that.globalData.miniBinId,
      version: that.globalData.tempVersion,
      menuId: num
    }, data => {
      if (back != undefined) {
        back(data)
      }
    }, err => {
      console.log(err)
    })
  },
  onShow: function (e) {
    wx.hideShareMenu()
    const that = this;
    // 首先判断版本

  }
})