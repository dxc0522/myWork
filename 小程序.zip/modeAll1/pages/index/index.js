// pages/pay/index/index.js
const https = require('../../utils/util.js');
const app = getApp();
let footLunbo = [];
Page({
  /**
   * 页面的初始数据
   */
  data: {
    lunIndex: 1,// 当前轮播位置
    markers: null,
    // 底部轮播
    footState: true,
    showPage: false
  },
  // 刷新页面
  redayPage() {
    const that = this,
      data = app.globalData.controls;
    // 设置颜色
    that.setData({
      allColor: app.globalData.color,
    })
    if (https.eachControl(data, "q_lunbo")) {
      // 顶部轮播
      https.requestData(app.globalData.domain + app.urls.lunbo, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        position: 6,
        isLook:1
      }, data => {
        that.setData({
          lunboTop: data.data
        })
      }, err => {
        console.log(err)
      })
    }
    if (https.eachControl(data, "q_goodCard")) {
      app.getMenus(8, function (data) {
        app.globalData.news = data.data;
        that.setData({
          buyCards: data.data
        })
      })
      // 购买优惠券列表
      https.requestData(app.globalData.domain + app.urls.buyCard, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        isNew:0
      }, data => {
        // console.log(data.data)
        that.setData({
          buyCard: data.data
        })
      }, err => {
        // console.log(err)
      })
    }
    if (https.eachControl(data, "q_good")) {
      app.getMenus(2, function (data) {
        app.globalData.goods = data.data;
        that.setData({
          goods: data.data
        })
      })
      // 商品推荐
      https.requestData(app.globalData.domain + app.urls.shopingList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        isShelf: 1,
        isRecommend: 1
      }, data => {
        that.setData({
          goodList: data.data
        })
      }, err => {
        console.log(err)
      })
    }
    if (https.eachControl(data, "q_news")) {
      app.getMenus(3, function (data) {
        app.globalData.news = data.data;
        that.setData({
          news: data.data
        })
      })
      // 新闻推荐
      https.requestData(app.globalData.domain + app.urls.news, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        isRecommend: 1
      }, data => {
        that.setData({
          newsData: data.data
        })
      }, err => {
        console.log(err)
      })
    }
    if (https.eachControl(data, "q_morecomplete")) {
      app.getMenus(7, function (data) {
        app.globalData.news = data.data;
        that.setData({
          shopMsgs: data.data
        })
      })
      // 店铺信息
      https.requestData(app.globalData.domain + app.urls.shopMsg, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
      }, data => {
        console.log()
        data = data.data[0];
        delete data.id;
        delete data.miniBinId;
        let dataType = false;
        for (var i in data) {
          if (data[i].length != 0 || data[i] != 0 && i != "wifiPass" && i != "wifiName") {
            that.setData({
              more: true,
              shopMsg: data
            })
            return
          }
        }
        that.setData({
          more: false
        })
      }, err => {
        console.log(err)
      })
    }
    if (https.eachControl(data, "q_case")) {
      app.getMenus(1, function (data) {
        app.globalData.news = data.data;
        that.setData({
          cases: data.data
        })
      })
      // 案例信息
      https.requestData(app.globalData.domain + app.urls.anli, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        isRecommend: 1,
      }, data => {
        // console.log(data)
        that.setData({
          anli: data.data
        })
      }, err => {
        console.log(err)
      })
    }
    if (https.eachControl(data, "q_miniAppbind")) {
      app.getMenus(5, function (data) {
        app.globalData.news = data.data;
        that.setData({
          aboutWe: data.data
        })
      })
      // 商家信息
      https.requestData(app.globalData.domain + app.urls.companyInfo, {
        id: app.globalData.miniBinId,
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
      }, data => {
        // 存到全局
        app.globalData.cmpMsg = data.data;
        // 地图
        that.setData({
          cmpMsg: data.data,
          markers: [{
            latitude: data.data.companyLat,
            longitude: data.data.companyLng,
            name: data.data.companyName,
            iconPath: "/img/mapAds.png",
            width: 40,
            height: 40,
            alpha: 1,
          }],
          controls: [{
            id: 1,
            iconPath: "/img/GPS.png",
            position: {
              left: 10,
              top: 90,
              width: 50,
              height: 50
            },
            clickable: true
          }]
        })
      }, err => {
        console.log(err)
      })
      // 底部环境相册
      https.requestData(app.globalData.domain + app.urls.imgList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
      }, data => {
        that.setData({
          lunboFoot: data.data
        })
        data.data.forEach(function (item) {
          footLunbo.push(item.image)
        })
        // console.log(that.data)
        wx.stopPullDownRefresh()
      }, err => {
        console.log(err)
      })
    }
  },
  // 点击地图气泡事件
  controltap() {
    var latitude = parseFloat(app.globalData.cmpMsg.companyLat);
    var longitude = parseFloat(app.globalData.cmpMsg.companyLng);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 20
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    
    if (wx.hideTabBar){
      wx.showTabBar()
    }
    app.userControl(function (data) {
      that.setData({
        case: https.eachControl(data, "q_case"),
        news: https.eachControl(data, "q_news"),
        card: https.eachControl(data, "q_card"),
        qmini: https.eachControl(data, "q_miniAppbind"),//基础功能
        more: https.eachControl(data, "q_morecomplete"),//配套信息
        lunbo: https.eachControl(data, "q_lunbo"),//轮播
        goodCard: https.eachControl(data, "q_goodCard"),//购买卡券
        userCard: https.eachControl(data, "q_userCard"),//卡券
        shopPay: https.eachControl(data, "q_shopPay"),//到店付
        showPage: true,
        good: https.eachControl(data, "q_good")
      })
      that.redayPage()
      wx.showTabBar()
      wx.startPullDownRefresh()
      // 初始化页面
    })
  },
  // 轮播
  footLunbo(event) {
    this.setData({
      lunIndex: event.detail.current + 1
    })
  },
  lubImg(event) {
    const that = this;
    wx.previewImage({
      current: footLunbo[that.data.lunIndex - 1], // 当前显示图片的http链接
      urls: footLunbo // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.redayPage();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return https.sharePage()
  }
})