// pages/pay/index/view/ourMap/map.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    markers: [{
      iconPath: "/img/mapAds.png",
      id: 0,
      latitude: 34.7633170000,
      longitude: 113.7034720000,
      width: 50,
      height: 50
    }],
  },
  openMap() {
    var that = this;
    var latitude = that.data.markers[0].latitude;
    var longitude = that.data.markers[0].longitude;
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 20
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var address=app.globalData.cmpMsg;
    console.log(address)
    this.setData({
      markers: [{
        iconPath: "/img/mapAds.png",
        id: 0,
        latitude: address.companyLat,
        longitude: address.companyLng,
        width: 50,
        height: 50
      }],
      cmpMsg:address
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  }
})