const https = require('../../../../utils/util.js');
let app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    controls: [{
      id: 1,
      iconPath: "/img/GPS.png",
      position: {
        left: 10,
        top: 90,
        width: 50,
        height: 50
      },
      clickable: true
    }]
  },
  // 点击地图气泡事件
  controltap() {
    var latitude = parseFloat(app.globalData.cmpMsg.companyLat);
    var longitude = parseFloat(app.globalData.cmpMsg.companyLng);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 20
    })
  },
  // 打电话
  playPhone() {
    let phoneList = [];
    if (app.globalData.cmpMsg.telePhoneOne) {
      phoneList.push(app.globalData.cmpMsg.telePhoneOne)
    }
    if (app.globalData.cmpMsg.telePhoneTwo) {
      phoneList.push(app.globalData.cmpMsg.telePhoneTwo)
    }
    wx.showActionSheet({
      itemList: phoneList,
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber: phoneList[res.tapIndex]
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    if (app.globalData.domain != "") {
      readyPage()
    } else {
      app.userControl(function () {
        app=getApp()
        // 商家信息
        https.requestData(app.globalData.domain + app.urls.companyInfo, {
          id: app.globalData.miniBinId,
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
        }, data => {
          readyPage(data.data)
        })
      })
    }
    function readyPage(data) {
      if (data == undefined) {
        data = app.globalData.cmpMsg;
      }
      that.setData({
        allColor: app.globalData.color,
        latitude: data.companyLat,
        longitude: data.companyLng,
        markers: [{
          latitude: data.companyLat,
          longitude: data.companyLng,
          name: data.companyName,
          iconPath: "/img/mapAds.png",
          width: 40,
          height: 40,
          alpha: 1,
        }],
        aboutUs: data,
        phoneList: [data.telePhoneOne, data.telePhoneTwo]
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return https.sharePage()
  }
})