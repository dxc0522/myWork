// pages/pay/index/view/gongao/gonggao.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1;
let pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    taps: "all",//分类
  },
  // 发送数据格式
  pushData() {
    const that = this.data,
      taps = that.taps;
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    };
    if (that.taps != "all") {
      pushData.categoryId = taps;
    }
    pageIndex = 2;
    return pushData
  },
  // 类型筛选
  tabs(e) {
    console.log(e)
    const that = this;
    that.setData({
      taps: e.currentTarget.id
    })
    wx.showNavigationBarLoading()
    https.requestData(app.globalData.domain + app.urls.news, that.pushData(), data => {
      console.log(data.data)
      this.setData({
        newsList: data.data,
      })
      // 设置总页数
      pageNum = data.page.pageCount;
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // 初始化页面
  readyPage() {
    const that = this;
    // 顶部轮播
    https.requestData(app.globalData.domain + app.urls.lunbo, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      position: 1,
      isLook: 1
    }, data => {
      // console.log(data.data)
      this.setData({
        lunbo: data.data
      })
    }, err => {
      console.log(err)
    })
    // 新闻列表列表
    https.requestData(app.globalData.domain + app.urls.newTypes, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      this.setData({
        newTypes: data.data
      })
    }, err => {
      console.log(err)
    })
    // 新闻列表
    https.requestData(app.globalData.domain + app.urls.news, that.pushData(), data => {
      // 设置总页数
      pageNum = data.page.pageCount;
      wx.stopPullDownRefresh()
      this.setData({
        newsList: data.data
      })
    }, err => {
      console.log(err)
    })
  },
  onLoad: function () {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this;
    that.readyPage()
    that.setData({
      allColor: app.globalData.color
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.readyPage()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function (e) {
    const that = this;
    if (pageIndex <= pageNum) {
      let pushData = that.pushData();
      pushData.pageIndex = pageIndex;
      // 新闻列表
      https.requestData(app.globalData.domain + app.urls.news, pushData, data => {
        // console.log(data.data)
        // 设置总页数
        this.setData({
          newsList: data.data
        })
      }, err => {
        console.log(err)
      })
    }
  }
})