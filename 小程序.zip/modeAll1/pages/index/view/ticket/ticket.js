// pages/pay/index/view/ticket/ticket.js
const https = require('../../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    payType: false,
    order: {
      id: 0,
      type: "card",
      money: 0
    }
  },
  // 组件内点击触发该方法
  updata(e) {
    this.setData({
      payType: false
    })
  },
  // 免费领取
  freePay() {
    const that = this;
    app.getUserMsg(function () {
      https.requestData(app.globalData.domain + app.urls.cardPay, {
        miniBindId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        id: app.globalData.userInfo.id,
        cardId: that.data.buyCard.id
      }, data => {
        console.log(data)
        wx.showToast({
          title: "领取成功",
          icon: 'sucess',
          mask: true
        })
        setTimeout(function () {
          app.getUserMsg(function () {
            wx.redirectTo({
              url: '/pages/me/view/meTicket/meTicket'
            })
          })
        }, 1000)
      }, err => {
        console.log(err)
        wx.showToast({
          title: err,
          image: '/img/error.png',
          duration: 1000,
          mask: true
        })
      })
    })

  },
  // 去付款
  goPay() {
    const that = this;
    function buyCard() {
      // 提示
      let pushData = {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        cardId: that.data.buyCard.id,
        orderType: 1,
        orderBuyType: 2,
      };
      // 提交订单
      https.requestData(app.globalData.domain + app.urls.addForm, pushData, data => {
        console.log(data)
        that.setData({
          payType: true,
          order: {
            id: data.data.id,
            money: data.data.money,
            type: "card"
          },
        })
        // 关闭提示
      }, err => {
        wx.showToast({
          title: err,
          image: '/img/error.png',
          duration: 1000,
          mask: true
        })
      })
    }
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        buyCard()
      })
    } else {
      buyCard()
    }


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    that.setData({
      cmdMsg: app.globalData.cmpMsg,
      allColor: app.globalData.color
    })
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: "#" + that.data.allColor,
      animation: {
        duration: 400,
        timingFunc: 'easeIn'
      }
    });
    // 购买优惠券列表
    https.requestData(app.globalData.domain + app.urls.buyCard, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      // console.log(data.data)
      for (var i in data.data) {
        if (data.data[i].id == options.id) {
          that.setData({
            buyCard: data.data[i],

          })
        }
      }
    }, err => {
      // console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})