// pages/pay/index/view/gongao/gonggao.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1;
let pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    taps: "all",//分类
  },
  // 设置data
  pushData() {
    const that = this.data,
      taps = that.taps;
    pageIndex = 2;
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }
    if (taps != "all") {
      pushData.categoryId = taps;
    }
    return pushData
  },
  // 类型筛选
  tabs(e) {
    const that = this;
    that.setData({
      taps: e.target.id
    })
    wx.showNavigationBarLoading()
    https.requestData(app.globalData.domain + app.urls.anli, that.pushData(), data => {
      console.log(data.data)
      wx.hideNavigationBarLoading()
      this.setData({
        anli: data.data,
      })
    }, err => {
      console.log(err)
    })
  },
  // 刷新页面
  readyPage(){
    const that = this;   
    // 顶部轮播
    https.requestData(app.globalData.domain + app.urls.lunbo, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      position: 2,
      isLook: 1
    }, data => {
      console.log(data.data)
      this.setData({
        lunbo: data.data
      })
    }, err => {
      console.log(err)
    })
    // 案例列表分类
    https.requestData(app.globalData.domain + app.urls.anliTypes, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      this.setData({
        anliTypes: data.data
      })
    }, err => {
      console.log(err)
    })
    // 案例列表
    https.requestData(app.globalData.domain + app.urls.anli, that.pushData(), data => {
      pageNum = data.page.pageCount;
      wx.stopPullDownRefresh()
      this.setData({
        anli: data.data,
      })
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this;
    that.readyPage()
    that.setData({
      allColor: app.globalData.color
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.readyPage()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log("到底了不要扯了！")
    const that = this;
    if (pageIndex <= pageNum) {
      let pushData = that.pushData();
      pushData.pageIndex = pageIndex;
      wx.showNavigationBarLoading()
      https.requestData(app.globalData.domain + app.urls.anli,pushData, data => {
        for(var i in data.data){
          that.data.anli.push(data.data[i])
        }
        that.setData({
          anli: that.data.anli
        })
        pageIndex += 1;
        wx.hideNavigationBarLoading()
      }, err => {
        console.log(err)
      })
    }
  }
})