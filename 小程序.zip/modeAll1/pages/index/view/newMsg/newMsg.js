// pages/pay/index/view/case/caseMsg/caseMsg.js
var WxParse = require('../../../../wxParse/wxParse.js');
const https = require('../../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showPage:false
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      caseId: options.id
    })
    if (app.globalData.domain != "") {
      readyPage()
    } else {
      app.userControl(function (data) {
        readyPage()
      })
    }
    function readyPage() {
      // 新闻详情
      https.requestData(app.globalData.domain + app.urls.newMsg, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        id: that.data.caseId
      }, data => {
        WxParse.wxParse('article', 'html', data.data.content, that, 20);
        that.setData({
          showPage: true,
          newMsg: data.data
        })
      }, err => {
        console.log(err)
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return https.sharePage()
  }
})