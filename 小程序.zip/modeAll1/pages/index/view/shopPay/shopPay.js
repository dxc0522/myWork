// pages/pay/index/index.js
const https = require('../../../../utils/util.js');
const app = getApp();
let cardId;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    payType: false,
    orderId: {
      id: 0,
      type: "shop"
    },
    payMoney: 0
  },
  // 组件内点击触发该方法
  updata: function (e) {
    this.setData({
      payType: false
    })
  },
  // 更改时更改金额
  blurChange(e) {
    const that = this;
    let order = that.data.orderId
    order.money = e.detail.value;
    that.setData({
      orderId: order
    })
    // if (payMoney != "" && that != undefined) {
    //   if (that.type == 1) {
    //     this.setData({
    //       payMoney: (payMoney - that.limitMoney > 0) ? payMoney - that.cutMoney : payMoney
    //     })
    //   } else if (that.type == 2) {
    //     this.setData({
    //       payMoney: payMoney * card.cutMoney
    //     })
    //   } else if (that.type == 3) {
    //     this.setData({
    //       payMoney: payMoney - that.cutMoney
    //     })
    //   }
    // } else {
    //   this.setData({
    //     payMoney: payMoney
    //   })
    // }
  },
  // 去付款
  goPay() {
    const that = this;
    app.getUserMsg(function (data) {
      if (that.data.orderId.money > 0) {
        let pushData = {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          userId: app.globalData.userInfo.id,
          orderType: 1,
          orderBuyType: 3,
          money: that.data.orderId.money
        };
        // 提交订单
        https.requestData(app.globalData.domain + app.urls.addForm, pushData, data => {
          console.log(data)
          let order = that.data.orderId;
          order.id=data.data.id
          that.setData({
            payType: true,
            orderId:order
          })
        }, err => {
          console.log(err)
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    cardId = options.id;
    this.setData({
      cmdMsg: app.globalData.cmpMsg,
      allColor:app.globalData.color
    })
    console.log(app.globalData)
    // if (options.id != undefined) {
    //   https.requestData(app.globalData.domain + app.urls.seachCard, {
    //     miniBinId: app.globalData.miniBinId,
    //     version: app.globalData.tempVersion,
    //     userId: app.globalData.userInfo.id,
    //     id: cardId
    //   }, data => {
    //     console.log(data.data)
    //     this.setData({
    //       card: data.data
    //     })
    //   }, err => {
    //     console.log(err)
    //   })
    // }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})