// pages/pay/index/view/gongao/gonggao.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    newsList: []
  },
  // 搜索
  formSubmit(e) {
    const that = this;
    wx.showNavigationBarLoading()
    that.setData({
      newsList:[]
    })
    https.requestData(app.globalData.domain + app.urls.anli, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      selectInfo: e.detail.value.seach
    }, data => {
      console.log(data)
      that.setData({
        newsList: data.data
      })
      wx.hideNavigationBarLoading()      
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // wx.showNavigationBarLoading()
    // 新闻列表 初始化
    // https.requestData(app.globalData.domain + app.urls.anli, {
    //   miniBinId: app.globalData.miniBinId,
    //   version: app.globalData.tempVersion,
    // }, data => {
    //   // console.log(data.data)
    //   for (var i in data.data) {
    //     data.data[i].createTime = https.readyTime(data.data[i].createTime)
    //   }
    //   this.setData({
    //     newsList: data.data
    //   })
    //   wx.hideNavigationBarLoading()
    //   console.log(data.data)
    // }, err => {
    //   console.log(err)
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})