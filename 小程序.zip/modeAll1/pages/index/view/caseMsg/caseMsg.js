// pages/pay/index/view/case/caseMsg/caseMsg.js
var WxParse = require('../../../../wxParse/wxParse.js');
const https = require('../../../../utils/util.js');
const app = getApp();
let caseId = 0;
let pageIndex = 1;
let pageNum = 0;
Page({
  // 播放视频
  playVideo() {
    this.setData({
      videoImg: true
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    taps: "all",//分类
    collect: false,//收藏状态
    like: false,//点赞状态
    video: {
      videoImg: false,
    },
    talkTxt: "",//回复内容
    showPage:false
  },
  // 点赞
  like(e) {
    const that = this;
    function setAction() {
      https.requestData(app.globalData.domain + app.urls.like, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: caseId,
        type: 1,
        userId: app.globalData.userInfo.id,
      }, data => {
        console.log(data)
        if (data.message == "数据修改成功!") {
          if (that.data.anliMsg.isPra == 1) {
            that.data.anliMsg.isPra = 0;
            that.data.anliMsg.praiseNum -= 1;
            that.setData({
              anliMsg: that.data.anliMsg
            })
          } else {
            that.data.anliMsg.isPra = 1;
            that.data.anliMsg.praiseNum += 1;
            that.setData({
              anliMsg: that.data.anliMsg
            })
          }
        }
        console.log(that.data.anliMsg)
      })
    }
    // 登录状态
    if (app.globalData.userInfo != null) {
      setAction()
    } else {
      app.getUserMsg(function () {
        wx.redirectTo({
          url: '/pages/index/view/caseMsg/caseMsg?id=' + caseId
        })
      })
    }
  },
  // 给评论点赞
  talkLike(e) {
    console.log(e)
    const that = this;
    const index = e.currentTarget.dataset.index;
    const talkList = that.data.anliTalk;
    function setAction() {
      https.requestData(app.globalData.domain + app.urls.like, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: index,
        type: 3,
        userId: app.globalData.userInfo.id,
      }, data => {
        console.log(data)
        // 遍历后更改选项的状态
        for (var i in talkList) {
          if (talkList[i].id == index) {
            if (talkList[i].isPra == 0) {
              talkList[i].isPra = 1,
                talkList[i].praiseNum += 1;
            } else {
              talkList[i].isPra = 0;
              talkList[i].praiseNum -= 1;
            }
            that.setData({
              anliTalk: talkList
            })
          }
        }
      })
    }
    console.log(app.globalData.userInfo != null)
    // 是否获取到用户信息
    if (app.globalData.userInfo != null) {
      setAction()
    } else {
      app.getUserMsg(function () {
        wx.redirectTo({
          url: '/pages/index/view/caseMsg/caseMsg?id=' + caseId
        })
      })
    }
  },
  // 收藏
  collect() {
    const that = this;
    function setAction() {
      // 更改收藏状态
      https.requestData(app.globalData.domain + app.urls.saveCollect, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: caseId,
        userId: app.globalData.userInfo.id,
        type: 1
      }, data => {
        // console.log(data)
        if (data.message == "没有查询到用户，新增用户成功") {
          wx.showToast({
            title: "收藏成功",
            icon: "success",
            duration: 1000,
          })
          that.setData({
            collect: true
          })
        } else {
          wx.showToast({
            title: "取消收藏",
            icon: "success",
            duration: 1000,
          })
          that.setData({
            collect: false
          })
        }
      }, err => {
        console.log(err)
      })
    }
    if (app.globalData.userInfo) {
      setAction()
    } else {
      app.getUserMsg(function () {
        wx.redirectTo({
          url: '/pages/index/view/caseMsg/caseMsg?id=' + caseId
        })
      })
    }
  },

  // 我的评论
  formSubmit(e) {
    var that = this;
    if (app.globalData.userInfo != null) {
      if (e.detail.value.talk.length !=0 || e.detail.value.talk != "") {
        https.requestData(app.globalData.domain + app.urls.anliTalkSub, {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          caseId: caseId,
          content: e.detail.value.talk,
          userId: app.globalData.userInfo.id
        }, data => {
          // console.log(data)
          wx.showToast({
            title: '评论成功',
            icon: 'success',
            duration: 1000,
            mask: true
          })
          setTimeout(function () {
            var pages = getCurrentPages() //获取加载的页面
            var currentPage = pages[pages.length - 1] //获取当前页面的对象
            var options = currentPage.options.id //如果要获取url中所带的参数可以查看options
            wx.redirectTo({
              url: "/pages/index/view/caseMsg/caseMsg?id=" + options
            })
          }, 1000)
        }, err => {
          console.log(err)
          wx.showToast({
            title: err,
            image: '/img/error.png',
            duration: 2000,
            mask: true
          })
          this.setData({
            talkTxt: ""
          })
        })
      } else {
        wx.showToast({
          title: "请输入评论内容",
          image: '/img/error.png',
          duration: 2000,
          mask: true
        })
      }
    }
  },
  // 绑定事件
  focusBind() {
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        wx.redirectTo({
          url: '/pages/index/view/caseMsg/caseMsg?id=' + caseId
        })
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    if (app.globalData.domain != "") {
      readyPage()
    } else {
      app.userControl(function (data) {
        readyPage(data)
      })
    }
    function readyPage(data) {
      if(data==undefined){
        let data = app.globalData.controls;
      }
      that.setData({
        anliCollect: https.eachControl(data, "q_caseCollect"),//案例收藏
        allColor: app.globalData.color,
        showPage:true
      })
      caseId = options.id;//案例Id
      let anliData = {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        id: options.id
      };
      let talkList = {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        caseId: caseId,
        type: 1
      };//案例评论列表数据初始化
      // 登录状态下则获取
      if (app.globalData.userInfo != null) {
        // 收藏状态
        https.requestData(app.globalData.domain + app.urls.isCollect, {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          itemId: caseId,
          userId: app.globalData.userInfo.id,
          type: 1
        }, data => {
          // console.log(data)
          if (data.data == 0) {
            that.setData({
              collect: false
            })
          } else {
            that.setData({
              collect: true
            })
          }
        }, err => {
          console.log(err)
        })
        // 更改评论列表数据
        talkList.selectUserId = app.globalData.userInfo.id;
        // 更改获取案例详情的数据
        anliData.selectUserId = app.globalData.userInfo.id;
      }
      // 案例详情
      https.requestData(app.globalData.domain + app.urls.anliMsg, anliData, data => {
        console.log(data)
        WxParse.wxParse('article', 'html', data.data.content, that, 19);
        that.setData({
          anliMsg: data.data
        })
      }, err => {
        console.log(err)
      })
      // 案例评价列表
      https.requestData(app.globalData.domain + app.urls.anliTalkList, talkList, data => {
        console.log(data)
        that.setData({
          anliTalk: data.data,
        })
        pageIndex = 2;
        pageNum = data.page.pageCount;
      }, err => {
        console.log(err)
      })
    }

  },
  // 下拉刷新
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (pageNum >= pageIndex) {
      https.requestData(app.globalData.domain + app.urls.anliTalkList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        caseId: caseId,
        pageIndex: pageIndex
      }, data => {
        // console.log(data)
        let anliTalk = this.data.anliTalk;
        for (var i in data.data) {
          anliTalk.push(data.data[i])
        }
        this.setData({
          anliTalk: anliTalk
        })
        pageIndex += 1
      }, err => {
        console.log(err)
      })
    } else {
      console.log("不要拉了，到底了")
    }
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const that = this;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return https.sharePage()
    // return {
    //   path: "/pages/index/view/caseMsg/caseMsg?id=" + caseId,
    //   title: that.anliMsg.title,
    //   success: function (res) {
    //     console.log(res)
    //     // 转发成功
    //   },
    //   fail: function (res) {
    //     // 转发失败
    //   }
    // }
  },
  // 滚动到底部 暂时放弃该写法
  // scrollFoot(e) {
  //   if (pageNum >= pageIndex) {
  //     https.requestData(app.globalData.domain + app.urls.anliTalkList, {
  //       miniBinId: app.globalData.miniBinId,
  //       version: app.globalData.tempVersion,
  //       caseId: caseId,
  //       pageIndex: pageIndex
  //     }, data => {
  //       // console.log(data)
  //       let anliTalk = this.data.anliTalk;
  //       for (var i in data.data) {
  //         anliTalk.push(data.data[i])
  //       }
  //       this.setData({
  //         anliTalk: anliTalk
  //       })
  //       pageIndex += 1
  //     }, err => {
  //       console.log(err)
  //     })
  //   }else{
  //     console.log("不要拉了，到底了")
  //   }
  // },
})