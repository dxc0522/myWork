// pages/pay/againSeting/againSeting.js
const https = require('../../../utils/util.js')
const app = getApp();
let urlData,
  links = {
    "set": "setPwd",
    "edt": "setPwd",
  }
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pwdLength: 0,
    inputFocus: true
  },
  // 获取焦点
  inputFocus() {
    this.setData({
      inputFocus: true
    })
  },
  // 更改密码输入
  changePwd(e) {
    this.setData({
      pwdLength: e.detail.cursor
    })
    if (e.detail.cursor >= 6) {
      if (e.detail.value == urlData.pwd) {
        // 设置发送数据
        let pushData = {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          id: app.globalData.userInfo.id,
          payPassWord: e.detail.value,
          phone: app.globalData.userInfo.phone
        };
        if (urlData.type == "edt") {
          pushData.content = urlData.code;
        }
        https.requestData(app.globalData.domain + app.urls[links[urlData.type]], pushData, data => {
          // console.log(data)
          wx.showToast({
            title: '设置成功',
            icon: 'success',
            duration: 2000,
            mask: true,
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 2000)
        },err=>{
          debugger
        })
      } else {
        wx.showToast({
          title: "两次密码不一致",
          image: '/img/error.png',
          duration: 2000,
          mask: true
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    urlData = options;//获取路径信息
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})