const https = require('../../../utils/util.js');
const app = getApp();
let phoneList;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    codeLength: 0,//验证码长度
    endTime: 60,// 倒计时时间
    inputFocus: true
  },
  // 获取焦点
  inputFocus() {
    this.setData({
      inputFocus: true
    })
  },
  // 再次获取验证码  找回密码
  againCode() {
    const that = this;
    https.requestData(app.globalData.domain + app.urls.sendCode, {
      type: 3,
      phone: phoneList,
      miniBindId: app.globalData.miniBinId,
    }, data => {
      console.log(data.data.content)
    })
    // 倒计时
    let t = setInterval(function () {
      if (that.data.endTime > 0) {
        that.data.endTime--;
        that.setData({
          endTime: that.data.endTime
        })
      } else {
        clearInterval(t)
      }
    }, 1000)
  },
  // 监听输入框
  codeInput(e) {
    const that = this;
    this.setData({
      codeLength: e.detail.cursor
    })
    if (e.detail.cursor >= 6) {
      https.requestData(app.globalData.domain + app.urls.edtPhone, {
        content: e.detail.value,
        phone: phoneList,
        oldPhone: app.globalData.userInfo.phone,
        miniBindId: app.globalData.miniBinId,
        id:app.globalData.userInfo.id
      }, data => {
        if (data.status =="success"){
          wx.showToast({
            title: "修改成功",
            icon: 'sucess',
            duration: 2000,
            mask: true
          })
          setTimeout(function () {
            app.updataUser(function(){
              wx.navigateBack({
                delta: 1,
              })
            })            
          }, 2000)
        }else{
          wx.showToast({
            title: data.msg,
            image: '/img/error.png',
            duration: 2000,
            mask: true
          })
          setTimeout(function(){
            wx.navigateBack({
              delta: 1,
            })
          },2000)
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    phoneList = options.phone;
    let phone = "";
    for (var i = 0; i < phoneList.length; i++) {
      if (i > 2 && i < 9) {
        phone += "*"
      } else {
        phone += phoneList[i]
      }
      that.setData({
        phone: phone
      })
    }
    that.againCode()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})