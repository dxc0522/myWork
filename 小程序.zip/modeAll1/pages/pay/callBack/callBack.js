// pages/pay/callBack/callBack.js
const https = require('../../../utils/util.js')
const app = getApp();
let orderId = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    orderId = options.order;
    https.requestData(app.globalData.domain + app.urls.formMsg, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      id: orderId,
    }, data => {
      this.setData({
        formMsg: data.data,
      })
    }, err => {
      console.log(err)
    })
  },
  // 联系商家
  tellCmd() {
    let phoneList = [];
    if (app.globalData.cmpMsg.telePhoneOne) {
      phoneList.push(app.globalData.cmpMsg.telePhoneOne)
    }
    if (app.globalData.cmpMsg.telePhoneTwo) {
      phoneList.push(app.globalData.cmpMsg.telePhoneTwo)
    }
    wx.showActionSheet({
      itemList: phoneList,
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber:phoneList[res.tapIndex]
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})