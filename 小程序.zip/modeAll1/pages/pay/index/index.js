const https = require('../../../utils/util.js');
const app = getApp();
let urlData;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    codeLength: 0,//验证码长度
    endTime: 60,// 倒计时时间
    inputFocus: true
  },
  // 获取焦点
  inputFocus() {
    this.setData({
      inputFocus: true
    })
  },
  // 密码输入改变
  changePwd(e) {
    const that = this;
    that.setData({
      pwdLength: e.detail.cursor,
    })
    if (e.detail.cursor >= 6) {
      that.setData({
        inputFocus: false
      })
      // 优惠券支付
      if (urlData.type == "card") {
        https.requestData(app.globalData.domain + app.urls.cardPay, {
          miniBindId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          orderId: urlData.order,
          payPassWord: e.detail.value
        }, data => {
          console.log(data)
          wx.showToast({
            title: "支付成功",
            icon: 'sucess',
            mask: true
          })
          setTimeout(function () {
            app.getUserMsg(function () {
              wx.redirectTo({
                url: '/pages/me/view/meTicket/meTicket'
              })
            })
          }, 1000)
        }, err => {
          console.log(err)
          wx.showToast({
            title: err,
            image: '/img/error.png',
            duration: 1000,
            mask: true
          })
        })
        // 门店付
      } else if (urlData.type == "shop") {
        https.requestData(app.globalData.domain + app.urls.shopPay, {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          orderId: urlData.order,
          payPassWord: e.detail.value
        }, data => {
          wx.showToast({
            title: "支付成功",
            icon: 'sucess',
            mask: true
          })
          setTimeout(function () {
            app.getUserMsg(function () {
              wx.redirectTo({
                url: '/pages/me/view/payHistory/payHistory'
              })
            })
          }, 1000)
        }, err => {
          wx.showToast({
            title: err,
            image: '/img/error.png',
            duration: 1000,
            mask: true
          })
        })
        // 商品购买
      } else if (urlData.type == "good") {
        https.requestData(app.globalData.domain + app.urls.yuEPay, {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          id: urlData.order,
          payPassWord: e.detail.value
        }, data => {
          console.log(data)
          wx.showToast({
            title: "支付成功",
            icon: 'sucess',
            duration: 1000,
            mask: true
          })
          setTimeout(function () {
            app.getUserMsg(function () {
              wx.redirectTo({
                url: '../callBack/callBack?order=' + urlData.order
              })
            })
          }, 1000)
        }, err => {
          console.log(err)
          wx.showToast({
            title: err,
            image: '/img/error.png',
            duration: 1000,
            mask: true
          })
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    urlData = options;

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this;
    let phoneList = app.globalData.userInfo.phone;
    let pho = "";
    for (var i = 0; i < phoneList.length; i++) {
      if (i > 2 && i < 9) {
        pho += "*"
      } else {
        pho += phoneList[i]
      }
    }
    that.setData({
      phone: pho
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})