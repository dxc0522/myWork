const https = require('../../../utils/util.js');
const app = getApp();
let phone = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    codeLength: 0,//验证码长度
    endTime: 60,// 倒计时时间
    inputFocus: true
  },
  // 获取焦点
  inputFocus() {
    this.setData({
      inputFocus: true
    })
  },
  // 监听输入框
  codeInput(e) {
    this.setData({
      codeLength: e.detail.cursor
    })
    if (e.detail.cursor >= 6) {
      https.requestData(app.globalData.domain + app.urls.bindPhone, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        id: app.globalData.userInfo.id,
        content: e.detail.value,
        phone: phone,
      }, data => {
        console.log(data)
        app.getUserMsg(function(){
          wx.redirectTo({
            url: '../pwd/pwd?type='+"set"
          })
        })
      }, err => {
        console.log(err)
        wx.showToast({
          title: err,
          image: '/img/error.png',
          duration: 2000,
          mask: true
        })
      })
    }
  },
  // 再次获取验证码
  againCode() {
    const that=this;
    https.requestData(app.globalData.domain + app.urls.sendCode, {
      type: 2,
      phone: phone,
      miniBindId: app.globalData.miniBinId,
    }, data => {
      console.log(data.data.content)
    })
    let t = setInterval(function () {
      if (that.data.endTime > 0) {
        that.data.endTime--;
        that.setData({
          endTime: that.data.endTime
        })
      } else {
        clearInterval(t)
        that.setData({
          endTime: 60
        })
      }
    }, 1000)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    let phoneList = options.phone;
    let pho = "";
    for (var i = 0; i < phoneList.length; i++) {
      if (i > 2 && i < 9) {
        pho += "*"
      } else {
        pho += phoneList[i]
      }
    }
    that.setData({
      phone: pho
    })
    phone = options.phone;    
    that.againCode()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})