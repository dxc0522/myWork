//index.js
//获取应用实例
const https = require('../../../utils/util.js');
const app = getApp();
let col1H = 0;
let col2H = 0;
let pageIndex = 1;
let pageIndexNum = 1;
let preTaps;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    col1: [],
    col2: [],
    taps: "all",//分类
    filt: "all",//排序
    goodsList: [],//数据列表
  },
  // 传值条件
  pushData() {
    const that = this;
    // 判断传值
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      isShelf:1
    };
    if (that.data.taps != "all") {
      pushData.categoryId = that.data.taps;
    }
    if (that.data.filt != "all") {
      pushData.sorts = that.data.filt
    }
    return pushData
    // 判断传值 end
  },
  // 设置数据
  getData(res) {
    const that = this;
    const taps = that.data.taps;
    pageIndexNum = res.page.pageCount;
    preTaps = taps;
    // 清空状态 end
    col1H = 0;
    col2H = 0;
    that.data.goodsList = res.data;
    that.setData({
      goodsList: that.data.goodsList,
      col1: [],
      col2: [],
    })
    pageIndex = 2;
    wx.hideNavigationBarLoading();
  },
  // 类型筛选
  tabs(e) {
    const that = this;
    if (preTaps != e.currentTarget.id) {
      this.setData({
        taps: e.currentTarget.id,
        goodsList: []
      })
      wx.showNavigationBarLoading()
      https.requestData(app.globalData.domain + app.urls.shopingList, that.pushData(), data => {
        that.getData(data)
      }, err => {
        console.log(err)
      })
    }
  },
  // 排序
  filter(e) {
    const that = this;
    if (that.data.filt != e.currentTarget.id) {
      that.setData({
        filt: e.currentTarget.id,
        goodsList: []
      })
      pageIndex = 1;
      wx.showNavigationBarLoading()
      https.requestData(app.globalData.domain + app.urls.shopingList, that.pushData(), data => {
        that.getData(data)
      }, err => {
        console.log(err)
      })
    }
  },
  // 刷新页面
  readyPage(){
    const that = this;
    that.setData({
      allColor: app.globalData.color
    })
    // 顶部轮播
    https.requestData(app.globalData.domain + app.urls.lunbo, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      position: 3,
      isLook: 1
    }, data => {
      // console.log(data)
      that.setData({
        lunboTop: data.data
      })
    }, err => {
      console.log(err)
    })
    // 产品列表分类
    https.requestData(app.globalData.domain + app.urls.shopingType, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      // console.log(data.data)
      that.setData({
        goodsTypes: data.data
      })
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    

  },
  // 瀑布流
  imgRead(e) {
    const scal = e.detail.height / e.detail.width;
    const that = this;
    const imgH = 172 * scal;
    if (col1H <= col2H) {
      col1H += (172 * scal + 103);
      for (var i in that.data.goodsList) {
        if (that.data.goodsList[i].id == e.target.id) {
          that.data.goodsList[i].imgH = imgH;
          that.data.col1.push(that.data.goodsList[i]);
          that.setData({
            col1: that.data.col1
          })
          break
        }
      }
    } else {
      col2H += (172 * scal + 103);
      for (var i in that.data.goodsList) {
        if (that.data.goodsList[i].id == e.target.id) {
          that.data.goodsList[i].imgH = imgH;
          that.data.col2.push(that.data.goodsList[i]);
          that.setData({
            col2: that.data.col2
          })
          break
        }
      }
    }
  },
  // 下拉加载
  imgUpdata() {
    const that = this;
    if (pageIndex <= pageIndexNum) {
      // 设置值
      let pushData = {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        pageIndex,
        isShelf: 1
      };
      if (that.data.taps != "all") {
        pushData.categoryId = that.data.taps;
      }
      if (that.data.filt != "all") {
        pushData.sorts = that.data.filt
      }
      // 加载动画
      wx.showNavigationBarLoading();
      https.requestData(app.globalData.domain + app.urls.shopingList, pushData, data => {
        this.setData({
          goodsList: data.data
        })
        pageIndex += 1;
        wx.hideNavigationBarLoading()
      }, err => {
        console.log(err)
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.readyPage()
    const that = this;
    if (preTaps != that.data.taps) {
      this.setData({
        goodsList: []
      })
      // 商品列表
      https.requestData(app.globalData.domain + app.urls.shopingList, that.pushData(), data => {
        console.log(data)
        that.getData(data)
      }, err => {
        console.log(err)
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})