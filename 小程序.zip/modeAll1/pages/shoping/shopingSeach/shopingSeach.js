//获取应用实例
const https = require('../../../utils/util.js');
const app = getApp();


let col1H = 0;
let col2H = 0;
let pageIndex = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    col1: [],
    col2: [],
  },
  // 搜索
  formSubmit(e) {
    pageIndex = 1;
    const that = this;
    that.setData({
      goodsList:[],
    })
     col1H = 0;
     col2H = 0;
    wx.showNavigationBarLoading()
    https.requestData(app.globalData.domain + app.urls.shopingList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      pageIndex: pageIndex,
      selectInfo: e.detail.value.seach,
      isShelf: 1
    }, data => {
      console.log(data)
      that.setData({
        col1: [],
        col2: [],
        goodsList: data.data,
      })
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  // 瀑布流
  imgRead(e) {
    const scal = e.detail.height / e.detail.width;
    const that = this;
    if (col1H <= col2H) {
      col1H += (172 * scal + 103);
      for (var i in that.data.goodsList) {
        that.data.goodsList[i].imgH = scal * 172;
        if (that.data.goodsList[i].id == e.target.id) {
          that.data.col1.push(that.data.goodsList[i])
          that.setData({
            col1: that.data.col1
          })
          break
        }
      }
    } else {
      col2H += (172 * scal + 103);
      for (var i in that.data.goodsList) {
        that.data.goodsList[i].imgH = scal * 172;
        if (that.data.goodsList[i].id == e.target.id) {
          that.data.col2.push(that.data.goodsList[i])
          that.setData({
            col2: that.data.col2
          })
          break
        }
      }
    }
  },
  // 下拉刷新
  imgUpdata() {
    const that = this;
    wx.showNavigationBarLoading()
    setTimeout(function () {
      wx.hideNavigationBarLoading()
    }, 2000)
    https.requestData(app.globalData.domain + app.urls.shopingList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      pageIndex,
      isShelf: 1
    }, data => {
      this.setData({
        goodsList: data.data
      })
      pageIndex += 1
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
this.setData({
  allColor:app.globalData.color
})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  }
})