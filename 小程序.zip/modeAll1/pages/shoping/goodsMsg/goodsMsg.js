// pages/shoping/goodsMsg/goodsMsg.js
var WxParse = require('../../../wxParse/wxParse.js');
const https = require('../../../utils/util.js');
const app = getApp();
let goodsId = 0;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    collect: false,//收藏
    footUpdata: true,
    list: [],
    clientHeight: 0,
    arr: [],
    arrHight: []
  },
  // 收藏
  collect() {
    const that = this;
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        updataCollect()
      })
    } else {
      updataCollect()
    }
    function updataCollect() {
      // 更改收藏状态
      https.requestData(app.globalData.domain + app.urls.saveCollect, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: goodsId,
        userId: app.globalData.userInfo.id,
        type: 2
      }, data => {
        console.log(data)
        if (that.data.collect) {
          wx.showToast({
            title: "收藏成功",
            icon: 'success',
            duration: 2000,
            mask: true
          })
        } else {
          wx.showToast({
            title: "取消收藏",
            icon: 'success',
            duration: 2000,
            mask: true
          })
        }
      }, err => {
        console.log(err)
      })
      that.setData({
        collect: !that.data.collect
      })
    }
  },
  // 底部展开
  footUpdata(event) {
    if (this.data.footUpdata) {
      this.setData({
        footUpdata: false,
      })
    }
  },
  //图片点击事件
  imgYu(event) {
    var src = event.currentTarget.dataset.src;//获取data-src
    var imgList = event.currentTarget.dataset.list;//获取data-list
    //图片预览
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: imgList // 需要预览的图片http链接列表
    })
  },
  // 立即购买
  nowBuy(e) {
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        wx.navigateTo({
          url: '../buyGoods/buyGoods?id=' + e.currentTarget.dataset.index
        })
      })
    } else {
      wx.navigateTo({
        url: '../buyGoods/buyGoods?id=' + e.currentTarget.dataset.index
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    goodsId = options.id;
    const that = this;
    if (app.globalData.domain != "") {
      readyPage()
    } else {
      app.userControl(function (data) {
        readyPage(data)
      })
    }
    function readyPage(data) {
      if (data == undefined) {
        data = app.globalData.controls;
      }
      that.setData({
        allColor: app.globalData.color,
        cmdMsg: app.globalData.cmpMsg,
        server: https.eachControl(data, "q_onlineService"),
        buy: https.eachControl(data, "q_order")
      })
      // 商品信息
      https.requestData(app.globalData.domain + app.urls.goodsMsg, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        id: goodsId,
      }, data => {
        WxParse.wxParse('article', 'html', data.data.imageText, that, 5);
        that.setData({
          goodsMsg: data.data
        })
      }, err => {
        console.log(err)
      })
      // 商品评论
      https.requestData(app.globalData.domain + app.urls.goodsTalkList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        goodId: goodsId,
      }, data => {
        for (var i in data.data) {
          if (data.data[i].image != undefined) {
            data.data[i].imageM = data.data[i].image.split(";")
          }
        }
        that.setData({
          goodsTalk: data.data
        })
      }, err => {
        console.log(err)
      })
      if (app.globalData.userInfo != null) {
        // 收藏状态
        https.requestData(app.globalData.domain + app.urls.isCollect, {
          miniBinId: app.globalData.miniBinId,
          version: app.globalData.tempVersion,
          itemId: options.id,
          userId: app.globalData.userInfo.id,
          type: 2
        }, data => {
          console.log(data)
          if (data.data == 0) {
            that.setData({
              collect: false
            })
          } else {
            that.setData({
              collect: true
            })
          }
        }, err => {
          console.log(err)
        })
      }
    }
    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return https.sharePage()
  }
})