// pages/shoping/goodsTalk/goodsTalk.js
const app = getApp();
const https = require('../../../utils/util.js');
let pageIndex = 1;
let pageNum = 1;
let goodsId = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stars: 3.5,
    taps: "all",
    goodsTalkNum: {
      goodNum: 0,
      imgNum: 0,
      midNum: 0,
      negNum: 0,
      totalNum: 0
    }
  },
  // 发送请求
  getData(pushData) {
    https.requestData(app.globalData.domain + app.urls.goodsTalkList, pushData, data => {
      console.log(data)
      for (var i in data.data) {
        if (data.data[i].image != undefined) {
          data.data[i].images = data.data[i].image.split(";")
        }
      }
      this.setData({
        goodsTalkList: data.data
      })
      pageIndex += 1;
      pageNum = data.page.pageCount;
    }, err => {
      console.log(err)
    })
  },
  // 类型切换
  tapChange(e) {
    pageIndex = 1;
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      goodId: goodsId,
    };//初始化数据
    if (e.currentTarget.id != "all") {
      // const startName = e.currentTarget.dataset.type;
      // pushData[startName] = 1;
      pushData.commendType = e.currentTarget.id;
    }
    this.getData(pushData);
    this.setData({
      taps: e.currentTarget.id
    })
  },
  // 点赞
  like(e) {
    const index = e.currentTarget.dataset.index;
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        wx.redirectTo({
          url: '/pages/shoping/goodsTalk/goodsTalk?id=' + goodsId
        })
      })
    } else {
      // 发送点赞请求
      https.requestData(app.globalData.domain + app.urls.like, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: index,
        type: 4,
        userId: app.globalData.userInfo.id,
      }, data => {
        console.log(data)
      })
      var goodsTalkList = this.data.goodsTalkList;
      for (var i in goodsTalkList) {
        if (goodsTalkList[i].id == index) {
          if (goodsTalkList[i].isPra == 0) {
            goodsTalkList[i].isPra = 1;
            goodsTalkList[i].praiseNum += 1
          } else if (goodsTalkList[i].isPra == 1) {
            goodsTalkList[i].isPra = 0;
            goodsTalkList[i].praiseNum -= 1
          }
        }
      }
      this.setData({
        goodsTalkList
      })
      console.log(goodsTalkList)
    }
  },
  //图片点击事件
  imgYu: function (event) {
    var src = event.currentTarget.dataset.src;//获取data-src
    var imgList = event.currentTarget.dataset.list;//获取data-list
    //图片预览
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: imgList // 需要预览的图片http链接列表
    })
  },
  // 滚动到底部
  footUpdata() {
    if (pageIndex <= pageNum) {
      https.requestData(app.globalData.domain + app.urls.goodsTalkList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        goodId: goodsId,
        pageIndex: pageIndex
      }, data => {
        console.log(data)
        for (var i in data.data) {
          this.data.goodsTalkList.push(data.data[i])
        }
        this.setData({
          goodsTalkList: this.data.goodsTalkList
        })
        pageIndex += 1;
      }, err => {
        console.log(err)
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      allColor:app.globalData.color
    })
    goodsId = options.id;
    // 获取评价数量
    https.requestData(app.globalData.domain + app.urls.goodsTalkNum, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      goodId: goodsId,
      goodStars: 5,
      midStars: 3,
      negStars: 1,
      image: 1,
    }, data => {
      console.log(data)
      this.setData({
        goodsTalkNum: data.data
      })
      pageIndex += 1;
    }, err => {
      console.log(err)
    })
    // 初始化列表
    // https.requestData(app.globalData.domain + app.urls.goodsTalkList, {
    //   miniBinId: app.globalData.miniBinId,
    //   version: app.globalData.tempVersion,
    //   goodId: goodsId,
    // }, data => {
    //   console.log(data)
    //   this.setData({
    //     goodsTalkList: data.data
    //   })
    //   pageIndex += 1;
    //   pageNum = data.page.pageCount
    // }, err => {
    //   console.log(err)
    // })
    var readyData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      goodId: goodsId,
    };
    if (app.globalData.userInfo != null) {
      readyData.selectUserId = app.globalData.userInfo.id;
    }
    this.getData(readyData)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  }
})