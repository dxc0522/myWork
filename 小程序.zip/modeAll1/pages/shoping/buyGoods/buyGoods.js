// pages/pay/index/view/ticket/ticket.js
const https = require('../../../utils/util.js');
const app = getApp();
let goodId = "";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    payType: false,
    showInvoice: false,
    orderId: {},//传入订单id与信息
    goodNum: 1,
    carMsg: false
  },
  // 加数量
  addNum() {
    let goodNum = this.data.goodNum;
    goodNum++
    this.setData({
      goodNum: goodNum
    })
    this.readayPage()
  },
  cutNum() {
    let goodNum = this.data.goodNum;
    goodNum--;
    if (goodNum <= 0) {
      goodNum = 1
    }
    this.setData({
      goodNum: goodNum
    })
    this.readayPage()
  },
  // 是否开具发票
  invoice(e) {
    this.setData({
      showInvoice: e.detail.value
    })
  },
  // 获取支付组件回调
  updata() {
    this.setData({
      payType: false
    })
  },
  // 去支付
  goPay(e) {
    const that = this;
    const formMsg = e.detail.value;
    let goodNum = this.data.goodNum;
    if (that.data.adsMsg == false) {
      wx.showToast({
        title: '请设置地址',
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    }
    // 提示
    wx.showLoading({
      title: '提交中',
    })
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      goodId: goodId,
      addrId: that.data.adsMsg.id,
      num: goodNum,
      orderType: 1,
      orderBuyType: 1,
      remark: formMsg.remark
    };
    if (that.data.carMsg) {
      pushData.cardId = that.data.goodsMsg.cardId
    }
    if (formMsg.bill) {
      pushData.invoiceTitle = formMsg.billTxt;
      pushData.invoiceRecognitionCode = formMsg.billCode;
    }
    // 提交订单
    https.requestData(app.globalData.domain + app.urls.addForm, pushData, data => {
      console.log(data)
      that.setData({
        orderId: {
          id: data.data.id,
          money: data.data.money,
          type: "good"
        },
        payType: true
      })
      // 关闭提示
      wx.hideLoading()
    }, err => {
      console.log(err)
      // 关闭提示
      wx.hideLoading()
      wx.showToast({
        title: err,
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
    })
  },
  // 刷新页面
  readayPage() {
    const that = this;
    // 权限控制
    let data = app.globalData.controls;
    let goodNum = this.data.goodNum;
    that.setData({
      piao: https.eachControl(data, "q_piao"),
      point: https.eachControl(data, "q_proportional"),
      userCard: https.eachControl(data, "q_userCard"),
    })
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      goodId: goodId,
      orderType: 0,
      orderBuyType: 1,
      num: goodNum
    };
    if (that.data.carMsg.id) {
      pushData.cardId = that.data.carMsg.id
    }
    // 预计算接口
    https.requestData(app.globalData.domain + app.urls.addForm, pushData, data => {
      this.setData({
        goodsMsg: data.data,
      })
    }, err => {
      console.log(err)
      wx.showToast({
        title: err,
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
    })
  },
  // 增加card
  addCard(carData) {
    const that = this;
    // 权限控制
    let data = app.globalData.controls;
    let goodNum = this.data.goodNum;
    that.setData({
      piao: https.eachControl(data, "q_piao"),
      point: https.eachControl(data, "q_proportional"),
      userCard: https.eachControl(data, "q_userCard"),
    })
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      goodId: goodId,
      orderType: 0,
      orderBuyType: 1,
      num: goodNum,
      cardId: carData.id
    };
    // 预计算接口
    https.requestData(app.globalData.domain + app.urls.addForm, pushData, data => {
      this.setData({
        goodsMsg: data.data,
        carMsg: carData
      })
    }, err => {
      console.log(err)
      wx.showToast({
        title: err,
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    goodId = options.id;
    const that = this;
    this.readayPage();
    that.setData({
      allColor: app.globalData.color,
      cmdMsg: app.globalData.cmpMsg
    })
    // 可用卡券
    https.requestData(app.globalData.domain + app.urls.meCard, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      status: 1
    }, data => {
      if (data.data.length != 0) {
        this.setData({
          carMsg: true
        })
      } else {
        this.setData({
          carMsg: false
        })
      }
    }, err => {
    })
    // 地址信息
    https.requestData(app.globalData.domain + app.urls.adsList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      isDef: 1
    }, data => {
      if (data.data.length == 0) {
        this.setData({
          adsMsg: false
        })
      } else {
        this.setData({
          adsMsg: data.data[0]
        })
      }
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})