// pages/pay/me/index.js
const https = require('../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phoneList: [],
    noteNum: 0
  },
  // 打电话
  bindPickerChange: function (e) {
    const that = this;
    wx.showActionSheet({
      itemList: that.data.phoneList,
      success: function (res) {
        wx.makePhoneCall({
          phoneNumber: that.data.phoneList[res.tapIndex]
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    let data = app.globalData.controls;
    that.setData({
      case: https.eachControl(data, "q_case"),
      myNote: https.eachControl(data, "q_message"),
      qmini: https.eachControl(data, "q_miniAppbind"),//基础功能
      more: https.eachControl(data, "q_morecomplete"),//配套信息
      goodCollect: https.eachControl(data, "q_goodCollect"),//商品收藏
      anliCollect: https.eachControl(data, "q_caseCollect"),//案例收藏
      mySelle: https.eachControl(data, "q_distribution"),//购买卡券
      userCard: https.eachControl(data, "q_userCard"),//卡券
      payHistory: https.eachControl(data, "q_moneydetail"),//支付记录
      piao: https.eachControl(data, "q_piao"),
      point: https.eachControl(data, "q_proportional"),
      order: https.eachControl(data, "q_order"),
      myads: https.eachControl(data, "q_address"),
      myBank: https.eachControl(data, "q_bankCard"),
      myTalk: https.eachControl(data, "q_goodCommend"),
      allColor: app.globalData.color
    })
  },
  // 刷新页面
  readyPage() {
    const that = this;
    if (app.globalData.userInfo == null) {
      app.getUserMsg(function () {
        updata()
      }, function () {
        wx.switchTab({
          url: '/pages/index/index'
        })
      })
    } else {
      app.updataUser(function () {
        updata()
      })
    }
    const updata = () => {
      let phoneList = [];
      if (app.globalData.cmpMsg.telePhoneOne) {
        phoneList.push(app.globalData.cmpMsg.telePhoneOne)
      }
      if (app.globalData.cmpMsg.telePhoneTwo) {
        phoneList.push(app.globalData.cmpMsg.telePhoneTwo)
      }
      that.setData({
        userInfo: app.globalData.userInfo,
        cmpMsg: app.globalData.cmpMsg,
        phoneList: phoneList
      })
      wx.stopPullDownRefresh()
      https.requestData(app.globalData.domain + app.urls.noLook, {
        miniBindId: app.globalData.miniBinId,
        id: app.globalData.userInfo.id,
      }, data => {
        that.setData({
          noteNum: data.data.unReadCount
        })
      }, err => {
        console.log(err)
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
    * 生命周期函数--监听页面显示
    */
  onShow: function () {
    this.readyPage()

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.readyPage()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})