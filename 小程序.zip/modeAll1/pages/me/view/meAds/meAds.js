const https = require('../../../../utils/util.js');
const app = getApp();
let val = [0, 0, 0];//地址下标
let makeType = "",//操作的不同路径
  edtIndex = "",//编辑下标
  provinceNum = 0,//省
  cityNum = 0,//市
  areaNum = 0,//区
  urlType = false,//进入路径
  pageIndex = 1,
  pageNum = 1;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    addAds: false,//添加收货地址
    alertType: false,//弹窗状态
    adsName: "",//用户名称
    adsPhone: "",//用户手机号
    adsMsg: "",//用户详细地址
    adsCity: "",//用户省市区级选项
  },
  // 返回页面信息
  backData(e) {
    if (urlType) {
      var pages = getCurrentPages(), //获取加载的页面
        currentPage = pages[pages.length - 2], //获取当前页面的对象
        adsList = this.data.adsList,
        num = e.currentTarget.dataset.id;
      for (var i in adsList) {
        if (adsList[i].id == num) {
          currentPage.setData({
            adsMsg: adsList[i]
          })
        }
      }
      wx.navigateBack({
        delta: 1,
      })
    }
  },
  // 弹出新增
  alertAdd() {
    this.setData({
      addAds: true,
    })
    makeType = "addAds"
  },
  // 关闭地址新增
  closeAdd() {
    this.setData({
      addAds: false,
      adsName: "",//用户名称
      adsPhone: "",//用户手机号
      adsMsg: "",//用户详细地址
      adsCity: "",//用户省市区级选项
    })
  },
  // 弹出新增地址选择
  alert() {
    const that = this;
    // 清空初始化
    that.province(data => {
      provinceNum = data.data[0].id;
      that.city(provinceNum, data => {
        cityNum = data.data[0].id
        that.area(cityNum, data => {
          areaNum = data.data[0].id
        })
      })
    })
    // 清空初始化 end
    this.setData({
      alertType: true
    })
    val = [0, 0, 0]
  },
  // 关闭新增地址选择
  close() {
    const that = this;
    let adsCity = that.data.province[val[0]].name
    if (that.data.city.length > 0) {
      adsCity += that.data.city[val[1]].name
    }
    if (that.data.area.length > 0) {
      adsCity += that.data.area[val[2]].name;
    }
    this.setData({
      alertType: false,
      adsCity
    })
  },
  // 操作地址信息
  updataAds(e) {
    const that = this;
    const adsName = e.detail.value.name;//姓名
    const adsPhone = e.detail.value.phone;//手机号
    const adsMsg = e.detail.value.adsMsg;//地址详细信息
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      name: adsName,
      provinceId: provinceNum,
      cityId: cityNum,
      areaId: areaNum,
      address: adsMsg,
      phone: adsPhone,
      isDef:0
    };//设置传送数据
    if (that.data.adsList.length<=0){
      pushData.isDef=1
    }
    // 若为编辑模式，增加id
    if (makeType == "defultAds") {
      pushData.id = that.data.adsList[edtIndex].id;
    }
    if (https.checkName(adsName) && https.checkPhone(adsPhone) && adsMsg.length > 0 && (provinceNum + "").length > 2) {
      https.requestData(app.globalData.domain + app.urls[makeType], pushData, data => {
        console.log(data)
        this.setData({
          addAds: false
        })
        that.readyPage()
      }, err => {
        console.log(err)
        wx.showToast({
          title: '操作失败',
          icon: 'cancel',
          duration: 1000
        })
      })
      that.closeAdd()
    } else {
      wx.showToast({
        icon: "none",
        title: '填写信息有误',
        duration: 1000,
        mask: true
      })
    }
  },
  // 弹出编辑地址
  edtAdsShow(e) {
    const that = this;
    edtIndex = e.currentTarget.id;//当前点击的地址
    // 清空初始化
    that.province(data => {
      provinceNum = data.data[0].id;
      that.city(provinceNum, data => {
        cityNum = data.data[0].id
        that.area(cityNum, data => {
          areaNum = data.data[0].id
        })
      })
    })
    // 清空初始化 end
    that.setData({
      addAds: true,
      adsName: that.data.adsList[edtIndex].name,
      adsPhone: that.data.adsList[edtIndex].phone,
      adsMsg: that.data.adsList[edtIndex].address,
      adsCity: that.data.adsList[edtIndex].provinceName + that.data.adsList[edtIndex].cityName + that.data.adsList[edtIndex].areaName,
    })
    makeType = "defultAds"//设置编辑模式
    provinceNum = that.data.adsList[edtIndex].provinceId;
    cityNum = that.data.adsList[edtIndex].cityId;
    areaNum = that.data.adsList[edtIndex].areaId;
  },
  // 选择默认地址
  defultAds(e) {
    console.log(e)
    const that = this;
    https.requestData(app.globalData.domain + app.urls.defultAds, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      id: e.currentTarget.id,
      userId: app.globalData.userInfo.id,
      isDef: 1
    }, data => {
      console.log(data)
      // 更改默认样式
      for (var i in that.data.adsList) {
        if (that.data.adsList[i].id == e.currentTarget.id) {
          that.data.adsList[i].isDef = 1
        } else {
          that.data.adsList[i].isDef = 0
        }
      }
      that.setData({
        adsList: that.data.adsList,
        addAds: false
      })
      that.readyPage()
    }, err => {
      console.log(err)
    })
  },
  // 省市联动
  bindChange: function (e) {
    console.log(e)
    const that = this;
    // 判断联动关系
    if (e.detail.value[0] == val[0]) {
      if (e.detail.value[1] == val[1]) {
        val = e.detail.value;
      } else {
        val = e.detail.value;
        val[2] = 0;
      }
    } else {
      val = [0, 0, 0];
      val[0] = e.detail.value[0];
    }
    provinceNum = that.data.province[val[0]].id;
    that.city(provinceNum, data => {
      if (data.data.length == 0) {
        that.setData({
          city: [],
          area: [],
        })
        cityNum = 0;
        areaNum = 0;
        return
      }
      that.setData({
        city: data.data,
      })
      cityNum = that.data.city[val[1]].id;
      that.area(cityNum, data => {
        if (data.data.length == 0) {
          that.setData({
            area: [],
          })
          areaNum = 0;
          return
        }
        that.setData({
          area: data.data,
        })
        areaNum = that.data.area[val[2]].id;
      })
    })
  },
  // 省
  province(back) {
    https.requestData(app.globalData.domain + app.urls.province, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      this.setData({
        province: data.data,
      })
      back(data)
    }, err => {
      console.log(err)
    })
  },
  // 市
  city(num, back) {
    https.requestData(app.globalData.domain + app.urls.city, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      fatherId: num
    }, data => {
      this.setData({
        city: data.data,
      })
      if (data.data.length > 0) {
        back(data)
      }
    }, err => {
      console.log(err)
    })
  },
  // 区
  area(num, back) {
    https.requestData(app.globalData.domain + app.urls.area, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      fatherId: num
    }, data => {
      this.setData({
        area: data.data,
      })
      if (data.data.length > 0) {
        back(data)
      }
    }, err => {
      console.log(err)
    })
  },
  // 删除收货地址
  removeAds(e) {
    const that = this;
    wx.showModal({
      title: '是否确认删除',
      success: function (res) {
        if (res.confirm) {
          console.log(e)
          https.requestData(app.globalData.domain + app.urls.remAds, {
            miniBinId: app.globalData.miniBinId,
            version: app.globalData.tempVersion,
            id: e.target.id,
          }, data => {
            console.log(data)
            that.readyPage()
          }, err => {
            console.log(err)
          })
        }
      }
    })
  },
  // 刷新页面列表
  readyPage(fn) {
    pageIndex=1;
    // 地址列表
    https.requestData(app.globalData.domain + app.urls.adsList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      pageIndex: pageIndex
    }, data => {
      pageIndex++;
      pageNum = data.page.pageCount;
      this.setData({
        adsList: data.data,
      })
      if (fn != undefined) {
        fn(data)
      }
      val = [0, 0, 0]
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.id != undefined) {
      urlType = true
    }
    const that = this;
    that.setData({
      allColor: app.globalData.color
    })
    pageIndex = 1;
    // 地址列表
    that.readyPage()
    that.province(data => {
      provinceNum = data.data[0].id;
      that.city(provinceNum, data => {
        cityNum = data.data[0].id
        that.area(cityNum, data => {
          areaNum = data.data[0].id
        })
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that = this;
    if (pageNum >= pageIndex) {
      https.requestData(app.globalData.domain + app.urls.adsList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        pageIndex: pageIndex
      }, data => {
        pageIndex++;
        data.data.forEach(item => {
          that.data.adsList.push(item)
        })
        that.setData({
          adsList: that.data.adsList,
        })
      }, err => {
        console.log(err)
      })
    }
  }
})