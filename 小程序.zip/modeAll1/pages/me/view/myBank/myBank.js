// pages/me/view/myBank/myBank.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1,
  pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userBankId: false
  },
  // 删除银行卡
  remBank(e) {
    const that = this;
    wx.showModal({
      title: '是否删除此银行卡',
      content: '',
      success: function (res) {
        if (res.confirm) {
          console.log(e.target.id)
          https.requestData(app.globalData.domain + app.urls.delBank, {
            miniBinId: app.globalData.miniBinId,
            version: app.globalData.tempVersion,
            userId: app.globalData.userInfo.id,
            id: e.target.id
          }, data => {
            pageIndex = 1;
            that.readyPage()
          }, err => {
            console.log(err)
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  // 初始化页面
  readyPage() {
    https.requestData(app.globalData.domain + app.urls.meBankList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      pageIndex: pageIndex
    }, data => {
      pageIndex++;
      pageNum = data.page.pageCount;
      for (var i in data.data) {
        data.data[i].card = data.data[i].card.slice(-4)
      }
      this.setData({
        bankList: data.data,
      })
    }, err => {
      console.log(err)
    })
  },
  // 选择银行卡
  change(e) {
    const that = this;
    if (that.data.userBankId) {
      var pages = getCurrentPages();
      var prevPage = pages[pages.length - 2];
      prevPage.setData({
        userBankId: e.currentTarget.id,
        userBankNum: e.currentTarget.dataset.card
      })
      // wx.navigateBack({
      //   delta: 1,
      // })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      allColor:app.globalData.color
    })
    // 判断打开方式
    if (options.id) {
      this.setData({
        userBankId: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    pageIndex = 1;
    this.readyPage()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that = this;
    if (pageNum >= pageIndex) {
      https.requestData(app.globalData.domain + app.urls.meBankList, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        pageIndex: pageIndex
      }, data => {
        pageIndex++;
        for (var i in data.data) {
          data.data[i].card = data.data[i].card.slice(-4)
        }
        data.data.forEach(item => {
          that.data.bankList.push(item)
        })
        this.setData({
          bankList: data.data,
        })
      }, err => {
        console.log(err)
      })
    }
  }
})