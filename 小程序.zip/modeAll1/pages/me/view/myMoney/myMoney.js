// pages/me/view/myMoney/myMoney.js
const https = require('../../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  // 增加余额
  addMoney(e) {
    console.log(e)
    const that = this;
    const formMsg = e.detail.value;
    // 提示
    wx.showLoading({
      title: '提交中',
      mask: true
    })
    // 提交订单
    https.requestData(app.globalData.domain + app.urls.addForm, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      goodId: e.currentTarget.dataset.id,
      orderType: 1,
      orderBuyType: 4,
    }, data => {
      // 发送微信支付请求
      https.requestData(app.globalData.domain + app.urls.wxPay, {
        id: data.data.id,
      }, back => {
        const data = back.data;
        wx.requestPayment({
          'timeStamp': data.timeStamp,
          'nonceStr': data.nonceStr,
          'package': data.package,
          'signType': data.signType,
          'paySign': data.paySign,
          'success': function (res) {
            wx.showToast({
              title: "充值成功",
              icon: 'success',
              duration: 2000,
              mask: true
            })
            setTimeout(function () {
              app.updataUser(function () {
                wx.redirectTo({
                  url: '/pages/me/view/myMoney/myMoney'
                })
              })
            }, 2000)
          },
          'fail': function (res) {
          }
        })
      }, err => {
        console.log(err)
      })
      // 关闭提示
      wx.hideLoading()
    }, err => {
      // 关闭提示
      wx.hideLoading()
      wx.showToast({
        title: err,
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    wx.showNavigationBarLoading()
    that.setData({
      allColor: app.globalData.color,
      myMoney: app.globalData.userInfo.balance
    })
    // 充值列表
    https.requestData(app.globalData.domain + app.urls.czList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      console.log(data)
      this.setData({
        czList: data.data
      })
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    const that = this;
    app.updataUser(function () {
      wx.stopPullDownRefresh()
      that.setData({
        myMoney: app.globalData.userInfo.balance
      })
    })
    // 充值列表
    https.requestData(app.globalData.domain + app.urls.czList, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
    }, data => {
      console.log(data)
      this.setData({
        czList: data.data
      })
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})