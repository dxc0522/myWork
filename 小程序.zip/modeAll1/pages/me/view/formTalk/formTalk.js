// pages/me/view/help/help.js
const https = require('../../../../utils/util.js');
const app = getApp();
let goodsId = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgList: [],
    talkStarts: 0,
    allColor: app.globalData.color,
    subType: false,
    talkMsg: ""
  },
  // 设置星级
  addStart(e) {
    this.setData({
      talkStarts: e.target.id
    })
    this.watchType()
  },
  // 判断输入状态
  // watchType(back) {
  //   const that = this;
  //   let subType = true;
  //   if (that.data.talkStarts == 0) {
  //     subType = false;
  //   } else if (that.data.talkMsg == "") {
  //     subType = false;
  //   }
  //   that.setData({
  //     subType: subType
  //   })
  // },
  // 查看输入状态
  inpChange(e) {
    this.setData({
      talkMsg: e.detail.value
    })
    this.watchType()
  },
  // 添加图片
  addImg() {
    let that = this;
    wx.chooseImage({
      count: 3, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgList: res.tempFilePaths
        })
        console.log(that.data.imgList)
      }
    })
  },
  // 删除图片
  removeImg(e) {
    var imgs = [],
      num = e.currentTarget.dataset.id,
      that = this;
    that.data.imgList.forEach(function (item, index) {
      if (index != num) {
        imgs.push(item)
      }
    })
    that.setData({
      imgList: imgs
    })
  },
  // 发表评论
  addTalk(e) {
    const that = this.data,
      imgNum = that.imgList.length;
    if (that.talkStarts == 0) {
      wx.showToast({
        title: "请选择星级",
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    } else if (that.talkMsg == "") {
      wx.showToast({
        title: "请留下您的意见",
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    }

    // 设置发送的数据
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      goodId: goodsId,
      userId: app.globalData.userInfo.id,
      content: e.detail.value.content,
      type:1,
      stars: that.talkStarts,
      orderId: that.formMsg.id
    };
    // 判断有无图片
    if (imgNum != 0) {
      pushData.image = [];
      that.imgList.forEach((item, num) => {
        wx.uploadFile({
          url: app.globalData.domain + app.urls.imgUpload,
          filePath: item,
          name: 'file',
          formData: {
            'user': 'test'
          },
          success: function (res) {
            pushData.image.push(res.data);
            if (pushData.image.length == imgNum) {
              pushData.image = pushData.image.join(";");
              sengTalk();
            }
          }
        })
      })
    } else {
      sengTalk()
    }
    function sengTalk() {
      wx.showLoading({
        title: '疯狂加载中',
        mask: true,
      })
      https.requestData(app.globalData.domain + app.urls.addGoodsTalk, pushData, data => {
        console.log(data)
        wx.hideLoading()
        wx.showToast({
          title: "评论成功",
          icon: 'success',
          duration: 2000,
          mask: true
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 2000)
      }, err => {
        console.log(err)
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    https.requestData(app.globalData.domain + app.urls.formMsg, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      id: options.id,
    }, data => {
      console.log(data)
      this.setData({
        formMsg: data.data,
      })
      goodsId = data.data.goodId
    }, err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})