// pages/me/view/formMsg/formMsg.js
const https = require('../../../../utils/util.js');
const app = getApp();
let orderId=0;//订单ID
Page({
  /**
   * 页面的初始数据
   */
  data: {
    payType: false
  },
  // 联系我们
  tellMe() {
    wx.makePhoneCall({
      phoneNumber: app.globalData.cmpMsg.telePhoneOne,
    })
  },
  // 去支付
  payMoney() {
    const orderMsg = this.data.formMsg;
    this.setData({
      orderId: {
        id: orderMsg.id,
        money: orderMsg.money,
        type: "good"
      },
      payType: true
    })
  },
  // 确认收货
  receive() {
    const that = this;
    wx.showModal({
      title: '是否收到货?',
      cancelText: "未收到",
      confirmText: "已收货",
      success: function (res) {
        if (res.confirm) {
          https.requestData(app.globalData.domain + app.urls.affirm, {
            miniBinId: app.globalData.miniBinId,
            version: app.globalData.tempVersion,
            id: that.data.formMsg.id
          }, data => {
            console.log(data)
            wx.redirectTo({
              url: '../formMsg/formMsg?id=' + that.data.formMsg.id,
            })
          }, ero => {
            console.log(ero)
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  // 获取支付组件回调
  updata() {
    this.setData({
      payType: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    orderId = options.id;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this;
    that.setData({
      allColor: app.globalData.color,
      cmdMsg: app.globalData.cmpMsg
    })
    https.requestData(app.globalData.domain + app.urls.formMsg, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      id: orderId,
    }, data => {
      if (data.data.status == 0) {
        this.setData({
          payTime: https.formatTime(data.data.createTime, 1800000)
        })
      }
      this.setData({
        formMsg: data.data,
      })
    }, err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})