// pages/me/view/meCollect/meCollect.js
const https = require('../../../../utils/util.js');
const app = getApp();
let checkBox=[],
  colectList = [],
  pageIndex = 1,
  pageNum = 1;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    edt: false,//是否编辑模式
    types: 2,//1案例2产品
    collectList: [],//案例列表
    allChecked: 0,//全部选中
    remNum: 0
  },
  // 案例跳转
  caseOpen(e) {
    const that = this;
    let collectList = that.data.collectList,
      readyNum = [],
      itemId = e.currentTarget.dataset.item,
      remNum = that.data.remNum;
    if (this.data.edt) {
      for (var i in collectList) {
        if (collectList[i].id == e.currentTarget.dataset.each) {
          collectList[i].checked = !collectList[i].checked;
          if (collectList[i].checked == true) {
            checkBox.push(itemId)
            remNum++
          } else {
            checkBox.forEach(item => {
              if (item != itemId) {
                readyNum.push(item)
              }
            })
            checkBox = readyNum;
            remNum--
          }
          break
        }
      };
      that.setData({
        remNum: remNum,
        collectList: collectList
      })
    } else {
      wx.navigateTo({
        url: '/pages/index/view/caseMsg/caseMsg?id=' + e.currentTarget.dataset.id,
      })
    }
  },
  // 商品跳转
  shopOpen(e) {
    const that = this;
    let collectList = that.data.collectList,
    readyNum=[],
    itemId = e.currentTarget.dataset.item,
      remNum = that.data.remNum;
    if (this.data.edt) {
      for (var i in collectList) {
        if (collectList[i].id == e.currentTarget.dataset.each) {
          collectList[i].checked = !collectList[i].checked;
          if (collectList[i].checked==true){
            checkBox.push(itemId)
            remNum++
          }else{
            checkBox.forEach(item=>{
              if (item != itemId){
                readyNum.push(item)
              }
            })
            checkBox=readyNum;
            remNum--
          }
          break
        }
      };
      that.setData({
        remNum: remNum,
        collectList: collectList
      })
    } else {
      wx.navigateTo({
        url: '/pages/shoping/goodsMsg/goodsMsg?id=' + e.currentTarget.dataset.id,
      })
    }
  },
  remove() {
    const that = this;
    // 删除
    for (var i in checkBox) {
      https.requestData(app.globalData.domain + app.urls.saveCollect, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        itemId: checkBox[i],
        userId: app.globalData.userInfo.id,
        type: that.data.types
      }, data => {
        console.log(data)
        that.readyPage();
      }, err => {
        console.log(err)
      })
    }
    checkBox = [];
    this.setData({
      edt: false,//是否编辑模式
      remNum: 0
    })
  },
  // 菜单切换
  types(e) {
    const that = this;
    this.setData({
      types: e.target.id,
      edt: false,
      collectList: null,
      remNum: 0,
      allChecked: 0
    })
    that.readyPage()
  },
  // 编辑
  edt() {
    this.setData({
      edt: true
    })
  },
  // 全选
  radioAll(e) {
    const collectList = this.data.collectList;
    if (e.detail.value.length == 1) {
      checkBox = [];
      for (var i in collectList) {
        collectList[i].checked = true;
        checkBox.push(collectList[i].itemId);
      }
      this.setData({
        allChecked: 1,
        collectList: collectList,
        remNum: collectList.length,
      })
    } else {
      for (var i in collectList) {
        collectList[i].checked = false
      }
      checkBox = [];
      this.setData({
        allChecked: 0,
        collectList: collectList,
        remNum: 0,
      })
    }
  },
  // 刷新页面
  readyPage() {
    const that = this;
    wx.showNavigationBarLoading()
    // 刷新案例列表
    https.requestData(app.globalData.domain + app.urls.meCollect, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      type: that.data.types,
    }, data => {
      pageIndex += 1;
      pageNum = data.page.pageCount
      // console.log(data)
      for (var i in data.data) {
        data.data[i].checked = false
      }
      colectList = data.data;
      this.setData({
        collectList: data.data
      })
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    that.setData({
      allColor: app.globalData.color
    })
    that.readyPage()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that = this;
    if (pageIndex <= pageNum) {
      wx.showNavigationBarLoading()
      // 刷新案例列表
      https.requestData(app.globalData.domain + app.urls.meCollect, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        type: that.data.types,
      }, data => {
        pageIndex += 1;
        // console.log(data)
        for (var i in data.data) {
          data.data[i].checked = false;
          colectList.push(data.data[i])
        }
        this.setData({
          collectList: colectList
        })
        wx.hideNavigationBarLoading()
      }, err => {
        console.log(err)
      })
    }
  }
})