// pages/me/view/meNote/meNote.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1,
  pageNum;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    taps: 1,
    systemEach: []
  },
  // tap切换
  changeTap(e) {
    const that = this;
    wx.showNavigationBarLoading()
    that.setData({
      taps: e.currentTarget.dataset.index
    })
    pageIndex = 1;
    switch (that.data.taps) {
      case "1":
        that.logisticsNote()
        break;
      case "2":
        that.systemNote()
        break;
    }
  },
  // 系统消息
  systemNote() {
    https.requestData(app.globalData.domain + app.urls.systemNote, {
      miniBinId: app.globalData.miniBinId,
      userId: app.globalData.userInfo.id,
      pageIndex: pageIndex
    }, data => {
      console.log(data)
      this.setData({
        systemEach: data.data
      })
      pageIndex += 1;
      pageNum = data.page.pageCount;
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  // 书城物流直接拿订单接口
  logisticsNote() {
    https.requestData(app.globalData.domain + app.urls.formList, {
      miniBinId: app.globalData.miniBinId,
      userId: app.globalData.userInfo.id,
      status: 2,
      pageIndex
    }, data => {
      console.log(data)
      this.setData({
        logisticsEach: data.data
      })
      pageIndex += 1;
      pageNum = data.page.pageCount;
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      allColor: app.globalData.color
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    pageIndex = 1;
    wx.showNavigationBarLoading()
    this.logisticsNote()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that = this;
    if (pageNum >= pageIndex) {
      switch (that.data.taps) {
        case "1":
          that.logisticsNote()
          break;
        case "2":
          that.systemNote()
          break;
      }
    }
  }
})