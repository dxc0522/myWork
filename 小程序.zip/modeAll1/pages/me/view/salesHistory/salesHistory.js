// pages/me/view/salesHistory/salesHistory.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1,
  pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    pageIndex = 1;
    https.requestData(app.globalData.domain + app.urls.moneyChange, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      type: 4,
      userId: app.globalData.userInfo.id,
      pageIndex: pageIndex
    }, data => {
      pageIndex++;
      pageNum = data.page.pageCount;
      this.setData({
        salesHistory: data.data
      })
    }, err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (pageIndex <= pageNum) {
      const that = this;
      https.requestData(app.globalData.domain + app.urls.moneyChange, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        type: 4,
        userId: app.globalData.userInfo.id,
        pageIndex: pageIndex
      }, data => {
        pageIndex++;
        data.data.forEach(item => {
          that.data.salesHistory.push(item)
        })
        that.setData({
          salesHistory: that.data.salesHistory
        })
      }, err => {
        console.log(err)
      })
    }
  }
})