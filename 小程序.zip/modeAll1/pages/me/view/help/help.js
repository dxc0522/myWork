// pages/me/view/help/help.js
const https = require('../../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgList: []
  },
  // 新增图片
  addImg() {
    let that = this;
    wx.chooseImage({
      count: 3, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        console.log(res)
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgList: res.tempFilePaths
        })
      }
    })
  },
  // 展示图片
  showImg(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.nowimg, // 当前显示图片的http链接
      urls: e.currentTarget.dataset.imgs // 需要预览的图片http链接列表
    })
  },
  // 删除图片
  removeImg(e) {
    var imgs = [],
      num = e.currentTarget.dataset.id,
      that = this;
    that.data.imgList.forEach(function (item, index) {
      if (index != num) {
        imgs.push(item)
      }
    })
    that.setData({
      imgList: imgs
    })
  },
  // 提交反馈
  btnForm(e) {
    wx.showLoading({
      title: '正在上传中',
      mask: true,
    })
    const that = this,
      imgNum = that.data.imgList.length;
    let imgs = [],
      pushData = {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        content: e.detail.value.content,
      };
    if (imgNum == 0) {
      sendData()
    } else {
      that.data.imgList.forEach(function (item) {
        wx.uploadFile({
          url: app.globalData.domain + app.urls.imgUpload,
          filePath: item,
          name: 'file',
          formData: {
            'user': 'test'
          },
          success: function (res) {
            imgs.push(res.data);
            if (imgs.length == imgNum) {
              pushData.images = imgs.join(";");
              sendData();
            }
          }
        })
      })
    }

    // 发送反馈
    function sendData() {
      https.requestData(app.globalData.domain + app.urls.help, pushData, data => {
        wx.hideLoading()
        wx.showToast({
          title: '反馈成功',
          icon: 'success',
          mask: true,
          duration: 1000
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1,
          })
        }, 1000)
      }, err => {
        wx.showToast({
          title: '反馈失败',
          image: '/img/error.png',
          mask: true,
          duration: 1000
        })
      })
    }
  },
  /**
   * 
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    that.setData({
      allColor: app.globalData.color
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})