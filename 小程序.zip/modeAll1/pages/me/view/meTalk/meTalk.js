// pages/shoping/goodsTalk/goodsTalk.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1,
  pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
  },
  //图片点击事件
  imgYu: function (event) {
    var src = event.currentTarget.dataset.src;//获取data-src
    var imgList = event.currentTarget.dataset.list;//获取data-list
    console.log(src, imgList)
    //图片预览
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: imgList // 需要预览的图片http链接列表
    })
  },
  // 加载页面
  readyPage() {
    wx.showNavigationBarLoading()
    https.requestData(app.globalData.domain + app.urls.myTalk, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      pageIndex
    }, data => {
      pageNum = data.page.pageCount;
      pageIndex += 1;
      for (var i in data.data) {
        if (data.data[i].image != undefined) {
          data.data[i].images = data.data[i].image.split(";");
        }
      }
      this.setData({
        talkList: data.data,
        talkListNum: data.page.totalCount
      })
      wx.stopPullDownRefresh()
      wx.hideNavigationBarLoading()
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    pageIndex=1;
    const that = this;
    that.setData({
      userInfo: app.globalData.userInfo,
      allColor: app.globalData.color
    })
    that.readyPage()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    pageIndex = 1;
    pageNum = 1;
    this.readyPage()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that=this;
    if (pageIndex <= pageNum) {
      wx.showNavigationBarLoading()
      https.requestData(app.globalData.domain + app.urls.myTalk, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        pageIndex
      }, data => {
        pageIndex += 1;
        for (var i in data.data) {
          if (data.data[i].image != undefined) {
            data.data[i].images = data.data[i].image.split(";");
          }
          that.data.talkList.push(data.data[i]);
        }
        this.setData({
          talkList: that.data.talkList,
        })
        wx.hideNavigationBarLoading()
      }, err => {
        console.log(err)
      })
    }
  }
})