const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = 1,
  pageNum = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  // 刷新页面
  readyPage() {
    https.requestData(app.globalData.domain + app.urls.moneyChange, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      type: 2,
      pageIndex: pageIndex
    }, data => {
      pageIndex++;
      pageNum = data.page.pageCount;
      this.setData({
        buyHistory: data.data
      })
    }, err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    pageIndex=1;
    this.readyPage()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    pageIndex = 1;
    this.readyPage()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    const that=this;
    if (pageNum > pageIndex) {
      https.requestData(app.globalData.domain + app.urls.moneyChange, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        userId: app.globalData.userInfo.id,
        type: 3,
        pageIndex: pageIndex
      }, data => {
        pageIndex++;
        data.data.forEach(item=>{
          that.data.buyHistory.push(item)
        })
        this.setData({
          buyHistory: that.data.buyHistory
        })
      }, err => {
        console.log(err)
      })
    }
  }
})