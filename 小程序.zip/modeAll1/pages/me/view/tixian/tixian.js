// pages/me/view/tixian/tixian.js
const https = require('../../../../utils/util.js');
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userBankId: null,
    userBankNum: 0,
  },
  tixian(e) {
    const that = this;
    if (that.data.userBankId == null){
      wx.showToast({
        title: "请选择银行卡",
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    }
    if (e.detail.value.money == "" || e.detail.value.money == "0"){
      wx.showToast({
        title: "请输入金额",
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    }
    if (!https.checkPhone(e.detail.value.phone) ) {
      wx.showToast({
        title: "手机号码不正确",
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      return
    }
    https.requestData(app.globalData.domain + app.urls.tixian, {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      money: e.detail.value.money,
      phone: e.detail.value.phone,
      userBankId: that.data.userBankId,
      userId: app.globalData.userInfo.id,
    }, data => {
      console.log(data)
      wx.showToast({
        title: "提现成功",
        icon: 'success',
        duration: 2000,
        mask: true
      })

    }, err => {
      wx.showToast({
        title: err,
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
    })
  },
  // 全部提现
  allTx() {
    this.setData({
      tixianNum: app.globalData.userInfo.distributionBalance
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    that.setData({
      allColor: app.globalData.color,
      userInfo: app.globalData.userInfo
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})