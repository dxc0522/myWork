// pages/me/view/meMsg/meMsg.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pushData = {};
Page({
  /**
   * 页面的初始数据
   */
  data: {
    endTime: 60
  },
  // 更换性别
  sex(e) {
    pushData.sex = e.detail.value;
  },
  // 更换头像
  changeIcon() {
    const that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        pushData.header = res.tempFilePaths[0];
        that.data.userInfo.header = pushData.header;
        that.setData({
          userInfo: that.data.userInfo
        })
      }
    })
  },
  // 提交个人信息
  edtMe(e) {
    console.log(e)
    wx.showLoading({
      title: '加载中',
      mask: true,
    })
    const formData = e.detail.value,
      that = this;
    pushData.nickName = formData.nickName;
    // 修改绑定手机号
    if (formData.phoneCode != undefined) {
      https.requestData(app.globalData.domain + app.urls.edtPhone, {
        miniBinId: app.globalData.miniBinId,
        version: app.globalData.tempVersion,
        type: 7,
        id: app.globalData.userInfo.id,
        phone: formData.phone,
        content: formData.phoneCode,
      }, data => {
        edtMsgs()
      }, err => {
        wx.showToast({
          title: err,
          image: '/img/error.png',
          duration: 2000,
          mask: true
        })
      })
    } else {
      edtMsgs()
    }
    function edtMsgs() {
      if (pushData.header != undefined) {
        wx.uploadFile({
          url: app.globalData.domain + app.urls.imgUpload,
          filePath: that.data.userInfo.header,
          name: 'file',
          formData: {
            'user': 'test'
          },
          success: function (res) {
            pushData.header = res.data;
            edtMsg()
          }
        })
      } else {
        edtMsg()
      }
      function edtMsg() {
        https.requestData(app.globalData.domain + app.urls.edtMe, pushData, data => {
          wx.hideLoading()          
          wx.showToast({
            title: '修改成功',
            icon: 'success',
            duration: 2000,
            mask: true
          })
        }, err => {
          wx.hideLoading()          
          wx.showToast({
            title: err,
            image: '/img/error.png',
            duration: 2000,
            mask: true
          })
        })
      }
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: app.globalData.userInfo,
      allColor: app.globalData.color,
      phoneCode: false
    })
    pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      id: app.globalData.userInfo.id,
      nickName: "",
      sex: app.globalData.userInfo.sex,
    };
  },
  // 手机号更改
  phoneNum(e) {
    console.log(e)
    const val = e.detail.value,
      that = this,
      prePhone = app.globalData.userInfo.phone;
    if (val.length < 11) {
      that.setData({
        phoneCode: false
      })
      return
    }
    if (val != prePhone && https.checkPhone(val)) {
      pushData.phone = val;
      that.setData({
        phoneCode: true,
      })
    } else {
      wx.showToast({
        title: '输入有误',
        image: '/img/error.png',
        duration: 2000,
        mask: true
      })
      that.setData({
        phoneCode: false
      })
    }
  },
  // 发送验证码
  againCode() {
    const that = this;
    if (that.data.endTime < 60) {
      return
    }
    https.requestData(app.globalData.domain + app.urls.sendCode, {
      type: 7,
      phone: pushData.phone,
      miniBindId: app.globalData.miniBinId,
    }, data => {
      console.log(data.data.content)
    })
    that.setData({
      endTime: 59
    })
    // 倒计时
    let t = setInterval(function () {
      if (that.data.endTime >= 1) {
        that.data.endTime--;
        that.setData({
          endTime: that.data.endTime
        })
      } else {
        clearInterval(t)
        that.setData({
          endTime: 60
        })
      }
    }, 1000)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})