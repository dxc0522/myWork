// pages/me/view/allForm/allForm.js
const https = require('../../../../utils/util.js');
const app = getApp();
let pageIndex = [],
  pageNum = [];
Page({
  /**
   * 页面的初始数据
   */
  data: {
    formMsg: [],
    taps: "0",
    tapsList: [0, 1, 2, 3, 4],//遍历列表数组
    getData: [[], [], [], [], []],//数据数组
    payType: false,
    scrollTop: 0
  },
  // 设置数据格式
  pushData() {
    wx.showNavigationBarLoading()
    const that = this;
    const taps = that.data.taps;
    let pushData = {
      miniBinId: app.globalData.miniBinId,
      version: app.globalData.tempVersion,
      userId: app.globalData.userInfo.id,
      pageIndex: pageIndex[taps],
      orderBuyType:1
    }
    if (that.data.taps != "0") {
      pushData.status = that.data.taps - 1;
    }
    pageIndex[taps] += 1;
    return pushData
  },
  // 设置展示格式
  getData(res) {
    wx.stopPullDownRefresh()
    const that = this;
    const taps = that.data.taps;
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
    // 总页数
    pageNum[taps] = res.page.pageCount;
    that.setData({
      getData: that.data.getData[taps] = []
    })
    that.data.getData[taps] = res.data;
    that.setData({
      getData: that.data.getData
    })
    wx.stopPullDownRefresh()
    wx.hideNavigationBarLoading()
  },
  // 菜单切换
  touchChange(e) {
    const changeType = e.type,
      that = this;
    if (changeType == "change") {
      let types = e.detail.current;
      that.setData({
        taps: types
      })
      pageIndex=[1,1,1,1,1];
      https.requestData(app.globalData.domain + app.urls.formList, that.pushData(), data => {
        that.getData(data)
      }, err => {
        console.log(err)
      })
    } else {
      that.setData({
        taps: e.currentTarget.id
      })
    }

  },
  // 下拉加载
  footUpdata() {
    const that = this;
    const taps = that.data.taps;
    if (pageIndex[taps] <= pageNum[taps]) {
      https.requestData(app.globalData.domain + app.urls.formList, that.pushData(), data => {
        // 总页数
        data.data.forEach(item => {
          that.data.getData[taps].push(item)
        })
        that.setData({
          getData: that.data.getData
        })
        wx.stopPullDownRefresh()
        wx.hideNavigationBarLoading()
      }, err => {
        console.log(err)
      })
    } else {
      console.log("到底了，不要扯了")
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    that.setData({
      taps: options.id,
      allColor: app.globalData.color,
    })
    // 初始化各页页数
    for (var i in that.data.tapsList) {
      pageIndex[i] = 1;
      pageNum[i] = 1;
    }
    https.requestData(app.globalData.domain + app.urls.formList, that.pushData(), data => {
      that.getData(data);
    }, err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("sdfasd")
    const that=this;
    debugger
    pageIndex=[1,1,1,1,1];
    https.requestData(app.globalData.domain + app.urls.formList, that.pushData(), data => {
      that.getData(data);
    }, err => {
      console.log(err)
    })
  },
  // 下拉触底
  onPullDownRefresh(e) {
    const that = this,
      types = that.data.taps;
    pageIndex[types] = 1;
    https.requestData(app.globalData.domain + app.urls.formList, that.pushData(), data => {
      that.getData(data)
    }, err => {
      console.log(err)
    })
  }
})